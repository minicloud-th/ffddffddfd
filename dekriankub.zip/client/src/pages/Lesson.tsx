import { useMemo, useState } from "react";
import { Link, useRoute } from "wouter";
import { ArrowLeft, ArrowUpRight, BookMarked, Check, ChevronDown, CircleHelp, Clock3, Copy, Download, FileText, Layers3, MoreHorizontal, Search, Send, Share2, Sparkles, Star } from "lucide-react";
import { toast } from "sonner";
import { suggestedQuestions } from "@/data/mockData";
import { askLesson, getLesson } from "@/services/mockStudyService";

const tabs = ["ภาพรวม", "สรุป", "ประเด็นสำคัญ", "คำศัพท์", "แบบทดสอบ", "ถาม AI"];

export default function Lesson() {
  const [, params] = useRoute("/lesson/:id");
  const lesson = getLesson(params?.id);
  const [activeTab, setActiveTab] = useState("ภาพรวม");
  const [vocabQuery, setVocabQuery] = useState("");
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState<{ answer: string; sources: string[] } | null>(null);
  const [asking, setAsking] = useState(false);

  const vocab = useMemo(() => lesson.vocabulary.filter(item => `${item.term} ${item.meaning}`.toLowerCase().includes(vocabQuery.toLowerCase())), [lesson.vocabulary, vocabQuery]);
  const ask = async (value = question) => {
    if (!value.trim()) return;
    setQuestion(value); setAsking(true); setAnswer(null);
    const response = await askLesson(value, lesson);
    setAnswer(response); setAsking(false);
  };

  const actionToast = (message: string) => toast.success(message, { description: "บันทึกการกระทำนี้ไว้ให้แล้ว" });

  return (
    <div className="lesson-page page-enter">
      <div className="page-topline"><Link href="/" className="back-link"><ArrowLeft size={16} /> บทเรียนทั้งหมด</Link><div className="lesson-top-actions"><button className="quiet-button" onClick={() => actionToast("คัดลอกลิงก์แล้ว")}><Share2 size={15} /> แชร์</button><button className="icon-button" onClick={() => actionToast("บันทึกเป็นรายการโปรดแล้ว")} aria-label="เพิ่มดาว"><Star size={17} fill={lesson.starred ? "currentColor" : "none"} /></button><button className="icon-button" aria-label="เมนูเพิ่มเติม"><MoreHorizontal size={18} /></button></div></div>
      <section className="lesson-hero"><div className="lesson-hero-icon"><BookMarked size={23} /></div><div className="lesson-title-block"><p className="eyebrow blue-eyebrow">{lesson.subject} · {lesson.grade}</p><h1>{lesson.title}</h1><p>{lesson.createdAt} · อ่านประมาณ {lesson.readingTime}</p></div><div className="lesson-hero-progress"><div className="progress-label"><span>ความคืบหน้า</span><strong>{lesson.progress}%</strong></div><div className="progress-track large"><i style={{ width: `${lesson.progress}%` }} /></div><span>ไปได้ดีมาก เหลืออีกนิดเดียว</span></div></section>
      <nav className="lesson-tabs" aria-label="เมนูในบทเรียน">{tabs.map(tab => <button key={tab} className={activeTab === tab ? "active" : ""} onClick={() => { setActiveTab(tab); if (tab === "แบบทดสอบ") window.location.href = `/quiz/${lesson.id}`; }}>{tab}{tab === "ถาม AI" && <Sparkles size={13} />}</button>)}</nav>

      {activeTab === "ภาพรวม" && <Overview lesson={lesson} setActiveTab={setActiveTab} />}
      {activeTab === "สรุป" && <Summary lesson={lesson} actionToast={actionToast} />}
      {activeTab === "ประเด็นสำคัญ" && <KeyPoints lesson={lesson} />}
      {activeTab === "คำศัพท์" && <Vocabulary lesson={lesson} vocab={vocab} query={vocabQuery} setQuery={setVocabQuery} />}
      {activeTab === "ถาม AI" && <AskAI lesson={lesson} question={question} setQuestion={setQuestion} answer={answer} asking={asking} ask={ask} />}
    </div>
  );
}

function Overview({ lesson, setActiveTab }: { lesson: ReturnType<typeof getLesson>; setActiveTab: (tab: string) => void }) {
  return <div className="lesson-content"><div className="overview-grid"><div className="overview-card"><Clock3 size={19} /><span>เวลาอ่านโดยประมาณ</span><strong>{lesson.readingTime}</strong><small>อ่านจบได้ในคาบเดียว</small></div><div className="overview-card"><Layers3 size={19} /><span>หัวข้อสำคัญ</span><strong>{lesson.keyPoints.length} หัวข้อ</strong><small>จัดเรียงตามเนื้อหา</small></div><div className="overview-card"><BookMarked size={19} /><span>คำศัพท์</span><strong>{lesson.vocabularyCount} คำ</strong><small>พร้อมตัวอย่าง</small></div><div className="overview-card"><CircleHelp size={19} /><span>แบบทดสอบ</span><strong>{lesson.quizCount} ข้อ</strong><small>ระดับ{lesson.difficulty}</small></div></div><div className="overview-columns"><section className="panel summary-preview"><div className="panel-head"><div><p className="eyebrow">สรุปสั้น ๆ</p><h2>เรื่องนี้เกี่ยวกับอะไร?</h2></div><button className="text-link" onClick={() => setActiveTab("สรุป")}>อ่านสรุปเต็ม <ArrowUpRight size={15} /></button></div><p className="highlight-quote">{lesson.summary}</p><div className="preview-footer"><span><Check size={15} /> อัปเดตเมื่อเร็ว ๆ นี้</span><button className="secondary-button compact" onClick={() => setActiveTab("แบบทดสอบ")}>ลองทำแบบทดสอบ</button></div></section><section className="panel key-preview"><div className="panel-head"><div><p className="eyebrow">จำไว้ให้ดี</p><h2>ประเด็นสำคัญ</h2></div><button className="icon-button" onClick={() => setActiveTab("ประเด็นสำคัญ")} aria-label="ดูประเด็นสำคัญ"><ArrowUpRight size={17} /></button></div><div className="key-preview-list">{lesson.keyPoints.slice(0, 3).map(point => <div className="key-preview-item" key={point.title}><span className={`point-number ${point.tone}`}>{lesson.keyPoints.indexOf(point) + 1}</span><div><strong>{point.title}</strong><p>{point.description}</p></div></div>)}</div></section></div><section className="continue-strip"><div><Sparkles size={18} /><div><strong>พร้อมทบทวนหรือยัง?</strong><span>ลองทำแบบทดสอบสั้น ๆ เพื่อเช็กความเข้าใจ</span></div></div><Link href={`/quiz/${lesson.id}`} className="primary-button">เริ่มทำแบบทดสอบ <ArrowUpRight size={16} /></Link></section></div>;
}

function Summary({ lesson, actionToast }: { lesson: ReturnType<typeof getLesson>; actionToast: (message: string) => void }) {
  return <div className="lesson-content narrow-content"><div className="summary-actions"><span className="eyebrow">สรุปบทเรียน</span><div><button className="quiet-button" onClick={() => actionToast("คัดลอกสรุปแล้ว")}><Copy size={15} /> คัดลอกสรุป</button><button className="quiet-button" onClick={() => actionToast("กำลังเตรียมไฟล์ดาวน์โหลด")}><Download size={15} /> ดาวน์โหลด</button></div></div><div className="summary-highlight"><span className="highlight-label">สรุปในหนึ่งย่อหน้า</span><p>{lesson.summary}</p></div><article className="long-summary"><h2>สรุปแบบละเอียด</h2><p>ลองมองบทเรียนนี้เป็นเส้นทางที่ค่อย ๆ เชื่อมจากแนวคิดพื้นฐานไปสู่การนำไปใช้จริง เราเรียบเรียงประเด็นให้เป็นลำดับ เพื่อให้กลับมาอ่านทบทวนได้โดยไม่ต้องเริ่มจากหน้าแรกใหม่ทุกครั้ง</p>{lesson.detailSummary.map((paragraph, index) => <div className="summary-paragraph" key={paragraph}><span>{String(index + 1).padStart(2, "0")}</span><p>{paragraph}</p></div>)}</article><div className="summary-cta-row"><button className="secondary-button" onClick={() => actionToast("ปรับสรุปให้สั้นลงแล้ว")}><ChevronDown size={16} /> ทำให้สั้นลง</button><button className="secondary-button" onClick={() => actionToast("กำลังอธิบายให้ง่ายขึ้น")}><Sparkles size={16} /> อธิบายให้ง่ายขึ้น</button><button className="secondary-button" onClick={() => actionToast("พร้อมขยายหัวข้อนี้แล้ว")}><ArrowUpRight size={16} /> ขยายหัวข้อนี้</button></div></div>;
}

function KeyPoints({ lesson }: { lesson: ReturnType<typeof getLesson> }) {
  return <div className="lesson-content"><div className="key-points-intro"><p className="eyebrow blue-eyebrow">ประเด็นที่อยากให้จำ</p><h2>เก็บภาพรวมไว้ก่อน แล้วค่อยลงรายละเอียด</h2><p>กลับมาดูหน้านี้ได้ทุกครั้งเวลาต้องการทบทวนเร็ว ๆ</p></div><div className="key-points-grid">{lesson.keyPoints.map((point, index) => <article className={`key-point-card tone-${point.tone}`} key={point.title}><div className="key-point-top"><span className="point-number">0{index + 1}</span><span>{point.label}</span></div><h3>{point.title}</h3><p>{point.description}</p><div className="key-point-line" /></article>)}</div></div>;
}

function Vocabulary({ lesson, vocab, query, setQuery }: { lesson: ReturnType<typeof getLesson>; vocab: ReturnType<typeof getLesson>["vocabulary"]; query: string; setQuery: (query: string) => void }) {
  return <div className="lesson-content"><div className="vocab-head"><div><p className="eyebrow blue-eyebrow">คำศัพท์สำคัญ</p><h2>คำที่ควรรู้จากบทเรียนนี้</h2><p>{lesson.vocabularyCount} คำที่ช่วยให้เข้าใจเนื้อหาได้เร็วขึ้น</p></div><label className="search-field"><Search size={17} /><input value={query} onChange={event => setQuery(event.target.value)} placeholder="ค้นหาคำศัพท์" /></label></div><div className="vocab-table"><div className="vocab-table-head"><span>คำศัพท์</span><span>ความหมาย</span><span>ตัวอย่าง</span></div>{vocab.length ? vocab.map(item => <div className="vocab-row" key={item.term}><strong>{item.term}</strong><p>{item.meaning}</p><p>{item.example}</p></div>) : <div className="empty-inline"><Search size={22} /><strong>ยังไม่พบคำนี้</strong><span>ลองใช้คำอื่นหรือค้นหาแบบสั้นลง</span></div>}</div></div>;
}

function AskAI({ lesson, question, setQuestion, answer, asking, ask }: { lesson: ReturnType<typeof getLesson>; question: string; setQuestion: (value: string) => void; answer: { answer: string; sources: string[] } | null; asking: boolean; ask: (value?: string) => void }) {
  return <div className="lesson-content ask-content"><div className="ask-intro"><div className="ask-orb"><Sparkles size={22} /></div><div><p className="eyebrow blue-eyebrow">ถามจากเอกสาร</p><h2>สงสัยตรงไหน ถามได้เลย</h2><p>เราจะตอบจากเนื้อหาใน “{lesson.title}” เท่านั้น</p></div></div><div className="suggested-prompts">{suggestedQuestions.map(prompt => <button key={prompt} onClick={() => ask(prompt)}>{prompt}<ArrowUpRight size={14} /></button>)}</div><div className="ask-box"><textarea value={question} onChange={event => setQuestion(event.target.value)} placeholder="เช่น ช่วยอธิบายเรื่องนี้ให้เห็นภาพหน่อย" rows={3} /><button className="send-button" onClick={() => ask()} disabled={!question.trim() || asking} aria-label="ส่งคำถาม">{asking ? <span className="loader-dot">•••</span> : <Send size={18} />}</button></div>{asking && <div className="answer-card thinking"><Sparkles size={18} /><span>กำลังเปิดดูเนื้อหาให้แป๊บหนึ่ง...</span></div>}{answer && !asking && <div className="answer-card"><div className="answer-head"><div className="answer-avatar"><Sparkles size={16} /></div><div><strong>dekriankub ช่วยตอบ</strong><span>อ้างอิงจากบทเรียนของคุณ</span></div></div><p>{answer.answer}</p><div className="answer-sources"><span>แหล่งอ้างอิง</span>{answer.sources.map(source => <em key={source}><FileText size={13} />{source}</em>)}</div></div>}</div>;
}
