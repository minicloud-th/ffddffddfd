import { useMemo, useState } from "react";
import { Link, useLocation } from "wouter";
import { BookOpen, Filter, FolderOpen, Grid2X2, List, Search, Star, StarOff } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

const subjectFilters = [
  { code: "ทั้งหมด", label: "ทั้งหมด" },
  { code: "TH", label: "ภาษาไทย" },
  { code: "MA", label: "คณิตศาสตร์" },
  { code: "SC", label: "วิทยาศาสตร์ฯ" },
  { code: "SO", label: "สังคมศึกษา" },
  { code: "HP", label: "สุขศึกษา" },
  { code: "AR", label: "ศิลปะ" },
  { code: "CA", label: "การงานอาชีพ" },
  { code: "LA", label: "ภาษาต่างประเทศ" },
];

const subjectImages: Record<string, string> = {
  TH: "/manus-storage/async-images/96CYSm4IeHmlsSqHILDrwM/image-1.webp",
  MA: "/manus-storage/async-images/96CYSm4IeHmlsSqHILDrwM/image-2.webp",
  SC: "/manus-storage/async-images/96CYSm4IeHmlsSqHILDrwM/image-3.webp",
  SO: "/manus-storage/async-images/96CYSm4IeHmlsSqHILDrwM/image-4.webp",
  HP: "/manus-storage/async-images/96CYSm4IeHmlsSqHILDrwM/image-5.webp",
  AR: "/manus-storage/async-images/ksop3BxzkTsUVu6ysW4x4k/image-1.webp",
  CA: "/manus-storage/async-images/ksop3BxzkTsUVu6ysW4x4k/image-2.webp",
  LA: "/manus-storage/async-images/ksop3BxzkTsUVu6ysW4x4k/image-3.webp",
};

export default function Library() {
  const [location] = useLocation();
  const [query, setQuery] = useState("");
  const [subject, setSubject] = useState("ทั้งหมด");
  const [favoritesOnly, setFavoritesOnly] = useState(location === "/favorites");
  const [view, setView] = useState<"grid" | "list">("grid");
  const [favorites, setFavorites] = useState<number[]>([]);
  const catalogQuery = trpc.catalog.list.useQuery({ search: query || undefined, subject: subject === "ทั้งหมด" ? undefined : subject, limit: 100 });
  const rows = catalogQuery.data ?? [];
  const filtered = useMemo(() => favoritesOnly ? rows.filter(row => favorites.includes(row.id)) : rows, [favorites, favoritesOnly, rows]);

  const toggleFavorite = (id: number) => {
    setFavorites(current => current.includes(id) ? current.filter(item => item !== id) : [...current, id]);
    toast.success("อัปเดตรายการโปรดแล้ว");
  };

  return <div className="library-page page-enter"><div className="page-topline"><span className="eyebrow"><span className="eyebrow-dot" /> คลังข้อมูลหลักสูตรจริง</span><button className="quiet-button" onClick={() => toast.message("จัดเรียงตามลำดับหลักสูตรและระดับชั้น")}><Filter size={15} /> จัดเรียง</button></div><div className="library-heading"><div><p className="eyebrow blue-eyebrow">Curriculum library · ม.1–ม.6</p><h1>คลังความรู้</h1><p>บทเรียนจาก 8 กลุ่มสาระ พร้อมแหล่งอ้างอิงและสถานะสิทธิ์</p></div><Link href="/upload" className="primary-button"><FolderOpen size={16} /> เพิ่มบทเรียน</Link></div><div className="library-toolbar"><label className="search-field large-search"><Search size={17} /><input value={query} onChange={event => setQuery(event.target.value)} placeholder="ค้นหาชื่อบทเรียน วิชา หรือหัวข้อ" /></label><div className="filter-pills">{subjectFilters.map(item => <button className={subject === item.code ? "selected" : ""} onClick={() => setSubject(item.code)} key={item.code}>{item.label}</button>)}</div><button className={`favorite-filter ${favoritesOnly ? "active" : ""}`} onClick={() => setFavoritesOnly(!favoritesOnly)}>{favoritesOnly ? <Star size={15} fill="currentColor" /> : <StarOff size={15} />} รายการโปรด</button><div className="view-switch"><button className={view === "grid" ? "active" : ""} onClick={() => setView("grid")} aria-label="มุมมองการ์ด"><Grid2X2 size={16} /></button><button className={view === "list" ? "active" : ""} onClick={() => setView("list")} aria-label="มุมมองรายการ"><List size={17} /></button></div></div>{catalogQuery.isLoading ? <div className="empty-state"><div className="empty-state-icon"><BookOpen size={22} className="spin" /></div><h2>กำลังเปิดคลังหลักสูตร</h2><p>กำลังโหลดบทเรียนจริงจากฐานข้อมูล</p></div> : catalogQuery.isError ? <div className="empty-state"><div className="empty-state-icon"><BookOpen size={22} /></div><h2>เปิดคลังข้อมูลไม่สำเร็จ</h2><p>ลองใหม่อีกครั้ง หรือตรวจการเชื่อมต่อฐานข้อมูล</p><button className="secondary-button" onClick={() => catalogQuery.refetch()}>ลองใหม่</button></div> : filtered.length ? <div className={`library-grid ${view === "list" ? "list-view" : ""}`}>{filtered.map(row => { const isFavorite = favorites.includes(row.id); return <Link href={`/catalog/${row.id}`} className="library-card" key={row.id}><div className={`library-card-top subject-${row.subjectCode === "TH" || row.subjectCode === "SC" ? "green" : row.subjectCode === "MA" || row.subjectCode === "LA" ? "blue" : "amber"}`} style={subjectImages[row.subjectCode] ? { backgroundImage: `linear-gradient(90deg, rgba(16,24,39,.86), rgba(16,24,39,.36)), url(${subjectImages[row.subjectCode]})` } : undefined}><BookOpen size={20} /><span>{row.subjectName} · {row.gradeLabel}</span><button className="card-star" onClick={event => { event.preventDefault(); toggleFavorite(row.id); }} aria-label="สลับรายการโปรด"><Star size={16} fill={isFavorite ? "currentColor" : "none"} /></button></div><div className="library-card-body"><h3>{row.title}</h3><p>{row.summary || "บทเรียนหลักสูตรไทยพร้อมเป้าหมายการเรียนรู้และหลักฐานการประเมิน"}</p><div className="card-tags"><span>{row.durationMinutes} นาที</span><span>{row.difficulty === "easy" ? "เริ่มต้น" : row.difficulty === "hard" ? "ท้าทาย" : "กำลังดี"}</span><span>อ้างอิงแล้ว</span></div></div><div className="library-card-footer"><div><span>แหล่งหลักสูตร</span><strong>{row.curriculumName}</strong></div><div className="progress-track"><i style={{ width: "0%" }} /></div><small>หน่วยเรียน · {row.gradeLabel}</small></div></Link>; })}</div> : <div className="empty-state"><div className="empty-state-icon"><Search size={22} /></div><h2>{favoritesOnly ? "ยังไม่มีรายการโปรด" : "ยังไม่เจอบทเรียนที่ค้นหา"}</h2><p>{favoritesOnly ? "กดดาวบนบทเรียนที่อยากกลับมาอ่านเร็ว ๆ ได้เลย" : "ลองเปลี่ยนคำค้นหรือเอาตัวกรองออก แล้วค้นหาใหม่อีกครั้ง"}</p><button className="secondary-button" onClick={() => { setQuery(""); setSubject("ทั้งหมด"); setFavoritesOnly(false); }}>ล้างตัวกรอง</button></div>}</div>;
}
