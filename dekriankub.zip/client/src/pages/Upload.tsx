import { useRef, useState } from "react";
import { Link, useLocation } from "wouter";
import { ArrowLeft, Check, FileText, FileUp, Loader2, Plus, Trash2, UploadCloud } from "lucide-react";
import { toast } from "sonner";
import type { UploadedFile } from "@shared/types";
import { fileToUpload, processingSteps, simulateProcessing, simulateUpload } from "@/services/mockStudyService";

const accepted = ["PDF", "DOCX", "PPTX", "JPG", "PNG", "TXT"];

export default function Upload() {
  const [, navigate] = useLocation();
  const inputRef = useRef<HTMLInputElement>(null);
  const [files, setFiles] = useState<UploadedFile[]>([]);
  const [dragging, setDragging] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [step, setStep] = useState(0);
  const [lessonName, setLessonName] = useState("");
  const [subject, setSubject] = useState("ชีววิทยา");
  const [level, setLevel] = useState("ม.4");
  const [detail, setDetail] = useState("กำลังดี");
  const [language, setLanguage] = useState("เข้าใจง่าย");

  const addFiles = (list: FileList | null) => {
    if (!list?.length) return;
    const incoming = Array.from(list).map(file => {
      if (file.size > 20 * 1024 * 1024) return { ...fileToUpload(file), status: "error" as const };
      const ext = file.name.split(".").pop()?.toLowerCase() ?? "";
      if (!["pdf", "docx", "pptx", "jpg", "jpeg", "png", "txt"].includes(ext)) return { ...fileToUpload(file), status: "error" as const };
      return fileToUpload(file);
    });
    setFiles(current => [...current, ...incoming]);
    const invalid = incoming.filter(file => file.status === "error");
    if (invalid.length) toast.error("มีไฟล์ที่ใช้ไม่ได้", { description: "ลองใช้ PDF หรือ DOCX ที่มีขนาดไม่เกิน 20 MB" });
    else toast.success(`เพิ่มไฟล์ ${incoming.length} ไฟล์แล้ว`);
  };

  const startProcessing = async () => {
    if (!files.length || files.some(file => file.status === "error")) {
      toast.error("ขอไฟล์เรียนสักไฟล์ก่อนนะ", { description: "เลือก PDF, DOCX, PPTX, JPG, PNG หรือ TXT ได้เลย" });
      return;
    }
    setProcessing(true);
    await simulateUpload(files);
    await simulateProcessing(currentStep => setStep(currentStep));
    toast.success("พร้อมเรียนแล้ว", { description: "เราจัดสรุปและแบบทดสอบไว้ให้แล้ว" });
    navigate("/lesson/digestion");
  };

  if (processing) {
    return <div className="processing-page page-enter"><Link href="/" className="back-link"><ArrowLeft size={16} /> กลับหน้าแรก</Link><div className="processing-shell"><div className="processing-icon"><UploadCloud size={25} /></div><p className="eyebrow blue-eyebrow">กำลังจัดบทเรียนให้คุณ</p><h1>เดี๋ยวเราช่วยจัดระเบียบ<br />เนื้อหาให้เอง</h1><p className="processing-copy">ใช้เวลาสักครู่ ระหว่างนี้พักสายตาได้เลย</p><div className="processing-progress"><div className="processing-progress-label"><span>{processingSteps[step].title}</span><strong>{Math.min(100, Math.round(((step + 1) / processingSteps.length) * 100))}%</strong></div><div className="progress-track large"><i style={{ width: `${Math.min(100, ((step + 1) / processingSteps.length) * 100)}%` }} /></div></div><div className="processing-steps">{processingSteps.map((item, index) => <div className={`processing-step ${index < step ? "complete" : ""} ${index === step ? "current" : ""}`} key={item.title}><span className="step-check">{index < step ? <Check size={13} /> : index === step ? <Loader2 size={13} className="spin" /> : index + 1}</span><div><strong>{item.title}</strong><small>{item.detail}</small></div></div>)}</div></div></div>;
  }

  return (
    <div className="upload-page page-enter">
      <div className="page-topline"><Link href="/" className="back-link"><ArrowLeft size={16} /> กลับหน้าแรก</Link><span className="step-label">ขั้นตอนที่ 1 จาก 2</span></div>
      <div className="upload-heading"><div><p className="eyebrow blue-eyebrow">บทเรียนใหม่</p><h1>วางไฟล์ไว้ตรงนี้<br />เดี๋ยวเราช่วยสรุปให้</h1><p>เพิ่มไฟล์เรียนของคุณ แล้วบอกเราอีกนิดว่าอยากเรียนแบบไหน</p></div><div className="upload-heading-number">01<span>/02</span></div></div>
      <div className="upload-layout">
        <section className="upload-main-column">
          <div className={`file-dropzone ${dragging ? "is-dragging" : ""}`} onDragEnter={event => { event.preventDefault(); setDragging(true); }} onDragOver={event => event.preventDefault()} onDragLeave={() => setDragging(false)} onDrop={event => { event.preventDefault(); setDragging(false); addFiles(event.dataTransfer.files); }}>
            <input ref={inputRef} type="file" hidden multiple accept=".pdf,.docx,.pptx,.jpg,.jpeg,.png,.txt" onChange={event => addFiles(event.target.files)} />
            <div className="dropzone-icon"><FileUp size={24} /></div><h2>{dragging ? "ปล่อยไฟล์ตรงนี้ได้เลย" : "ลากไฟล์มาวางที่นี่"}</h2><p>หรือเลือกไฟล์จากเครื่องของคุณ</p><button className="secondary-button" onClick={() => inputRef.current?.click()}><Plus size={16} /> เลือกไฟล์</button><span className="file-types">{accepted.map(type => <span key={type}>{type}</span>)}</span>
          </div>
          {files.length > 0 && <div className="uploaded-files"><div className="field-heading"><h3>ไฟล์ที่เลือก <span>{files.length}</span></h3><button className="text-button" onClick={() => inputRef.current?.click()}>+ เพิ่มไฟล์</button></div>{files.map(file => <div className={`file-row ${file.status === "error" ? "file-error" : ""}`} key={file.id}><div className="file-type-icon"><FileText size={17} /></div><div className="file-row-copy"><strong>{file.name}</strong><span>{file.type} · {file.size} {file.status === "error" && <em>ไฟล์นี้ใช้ไม่ได้</em>}</span></div><span className="file-status">{file.status === "error" ? "ตรวจสอบ" : "พร้อม"}</span><button className="icon-button danger-icon" onClick={() => setFiles(current => current.filter(item => item.id !== file.id))} aria-label={`ลบ ${file.name}`}><Trash2 size={16} /></button></div>)}</div>}
          <div className="form-section"><div className="field-heading"><h3>เล่าให้เรารู้จักบทเรียนนี้หน่อย</h3><span>ไม่ต้องกรอกครบก็ได้</span></div><label className="field-label">ชื่อชุดบทเรียน<input value={lessonName} onChange={event => setLessonName(event.target.value)} placeholder="เช่น ระบบย่อยอาหาร" /></label><div className="form-grid"><label className="field-label">วิชา<select value={subject} onChange={event => setSubject(event.target.value)}><option>ชีววิทยา</option><option>คณิตศาสตร์</option><option>ประวัติศาสตร์</option><option>วิทยาศาสตร์</option></select></label><label className="field-label">ระดับชั้น<select value={level} onChange={event => setLevel(event.target.value)}><option>ม.3</option><option>ม.4</option><option>ม.5</option><option>ม.6</option><option>มหาวิทยาลัย</option></select></label></div><label className="field-label">อยากเรียนเรื่องนี้เพื่ออะไร?<input placeholder="เช่น เตรียมสอบกลางภาค หรือทบทวนก่อนทำการบ้าน" /></label><div className="form-grid"><fieldset><legend className="field-label">ระดับความละเอียดของสรุป</legend><div className="segmented-control">{["สั้น", "กำลังดี", "ละเอียด"].map(value => <button type="button" key={value} className={detail === value ? "selected" : ""} onClick={() => setDetail(value)}>{value}</button>)}</div></fieldset><fieldset><legend className="field-label">รูปแบบภาษา</legend><div className="segmented-control">{["เข้าใจง่าย", "แบบตำราเรียน", "เน้นสอบ"].map(value => <button type="button" key={value} className={language === value ? "selected" : ""} onClick={() => setLanguage(value)}>{value}</button>)}</div></fieldset></div></div>
        </section>
        <aside className="upload-side-column"><div className="side-note"><div className="side-note-icon"><FileUp size={18} /></div><strong>เคล็ดลับเล็ก ๆ</strong><p>ถ้ามีหลายไฟล์ในบทเดียวกัน วางพร้อมกันได้เลย เราจะช่วยเชื่อมเนื้อหาให้เป็นเรื่องเดียวกัน</p></div><div className="side-note muted-note"><strong>ข้อมูลของคุณปลอดภัย</strong><p>ไฟล์นี้จะอยู่ในคลังความรู้ส่วนตัวของคุณ และใช้เพื่อช่วยจัดบทเรียนเท่านั้น</p></div></aside>
      </div>
      <div className="sticky-action-bar"><span>{files.length ? `${files.length} ไฟล์พร้อมวิเคราะห์` : "ยังไม่ได้เลือกไฟล์"}</span><button className="primary-button large-button" onClick={startProcessing} disabled={processing}><SparkleIcon /> เริ่มวิเคราะห์บทเรียน <ArrowRightIcon /></button></div>
    </div>
  );
}

function SparkleIcon() { return <span className="button-sparkle">✦</span>; }
function ArrowRightIcon() { return <span aria-hidden="true">→</span>; }
