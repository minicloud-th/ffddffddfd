import { Link } from "wouter";
import { useRef, useState } from "react";
import {
  ArrowUpRight,
  BookOpen,
  BrainCircuit,
  Check,
  Clock3,
  FileUp,
  FolderOpen,
  MoreHorizontal,
  Plus,
  Sparkles,
  Star,
  TrendingUp,
} from "lucide-react";
import { toast } from "sonner";
import { lessons, studyProgress } from "@/data/mockData";

function LessonRow({ id, title, subject, grade, progress, starred }: { id: string; title: string; subject: string; grade: string; progress: number; starred: boolean }) {
  return (
    <Link href={`/lesson/${id}`} className="lesson-row">
      <div className={`subject-icon subject-${subject === "ชีววิทยา" ? "green" : subject === "คณิตศาสตร์" ? "blue" : "amber"}`}>
        {subject === "ชีววิทยา" ? <Sparkles size={18} /> : subject === "คณิตศาสตร์" ? <span>∑</span> : <BookOpen size={18} />}
      </div>
      <div className="lesson-row-main">
        <div className="lesson-row-title"><strong>{title}</strong>{starred && <Star size={13} fill="currentColor" />}</div>
        <span>{subject} · {grade}</span>
      </div>
      <div className="lesson-row-progress"><span>{progress}%</span><div className="progress-track"><i style={{ width: `${progress}%` }} /></div></div>
      <ArrowUpRight size={17} className="row-arrow" />
    </Link>
  );
}

export default function Home() {
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragging, setDragging] = useState(false);

  const handleFiles = (files: FileList | null) => {
    if (!files?.length) return;
    toast.success(`รับไฟล์ ${files.length} ไฟล์แล้ว`, { description: "ไปต่อที่หน้าตั้งค่าบทเรียนได้เลย" });
  };

  return (
    <div className="home-page page-enter">
      <div className="page-topline"><span className="eyebrow"><span className="eyebrow-dot" /> วันพฤหัสบดีที่ 4 ตุลาคม 2569</span><button className="quiet-button"><Clock3 size={15} /> ประวัติการเรียน</button></div>
      <section className="welcome-block">
        <div>
          <p className="eyebrow blue-eyebrow">กลับมาเรียนต่อกัน</p>
          <h1>สวัสดี วันนี้อยากเรียน<br className="desktop-only" />เรื่องอะไรดี?</h1>
          <p className="welcome-copy">วางไฟล์เรียนไว้ แล้วให้ dekriankub ช่วยสรุปและเตรียมแบบทดสอบให้</p>
        </div>
        <div className="welcome-mark" aria-hidden="true"><div className="mark-ring ring-one" /><div className="mark-ring ring-two" /><div className="mark-core"><Sparkles size={22} /></div></div>
      </section>

      <section className={`upload-card ${dragging ? "is-dragging" : ""}`} onDragEnter={event => { event.preventDefault(); setDragging(true); }} onDragOver={event => event.preventDefault()} onDragLeave={() => setDragging(false)} onDrop={event => { event.preventDefault(); setDragging(false); handleFiles(event.dataTransfer.files); }}>
        <input ref={inputRef} type="file" hidden multiple accept=".pdf,.docx,.pptx,.jpg,.jpeg,.png,.txt" onChange={event => handleFiles(event.target.files)} />
        <div className="upload-card-icon"><FileUp size={22} /></div>
        <div className="upload-card-copy"><h2>{dragging ? "ปล่อยไฟล์ตรงนี้ได้เลย" : "วางไฟล์ของคุณที่นี่"}</h2><p>รองรับ PDF, DOCX, PPTX, JPG, PNG และไฟล์ข้อความ</p></div>
        <button className="primary-button" onClick={() => inputRef.current?.click()}><Plus size={17} /> อัปโหลดไฟล์</button>
        <span className="upload-note">หรือ ลากไฟล์มาวางในพื้นที่นี้</span>
      </section>

      <div className="section-heading"><div><p className="eyebrow">ภาพรวมการเรียน</p><h2>เรียนต่อจากตรงนี้</h2></div><Link href="/library" className="text-link">ดูทั้งหมด <ArrowUpRight size={15} /></Link></div>
      <div className="dashboard-grid">
        <section className="panel lessons-panel"><div className="panel-head"><div><h3>บทเรียนล่าสุด</h3><p>เปิดมาเรียนต่อได้ทันที</p></div><Link href="/library" className="icon-button" aria-label="เปิดคลังความรู้"><FolderOpen size={17} /></Link></div><div className="lesson-list">{lessons.map(lesson => <LessonRow key={lesson.id} {...lesson} />)}</div></section>
        <section className="panel progress-panel"><div className="panel-head"><div><h3>ความคืบหน้าสัปดาห์นี้</h3><p>คุณเรียนไปแล้ว {studyProgress.minutesThisWeek} นาที</p></div><div className="panel-kebab"><MoreHorizontal size={18} /></div></div><div className="progress-summary"><div className="progress-number"><strong>72</strong><span>%</span><small>เป้าหมายสัปดาห์</small></div><div className="circular-progress"><svg viewBox="0 0 42 42"><circle className="circle-bg" cx="21" cy="21" r="15.5" /><circle className="circle-value" cx="21" cy="21" r="15.5" /></svg><Check size={19} /></div></div><div className="week-bars">{studyProgress.weekly.map(day => <div className="day-bar" key={day.day}><div className={`bar ${day.active ? "active" : ""}`} style={{ height: `${Math.max(day.minutes * 1.7, 10)}px` }}><span>{day.minutes}</span></div><small>{day.day}</small></div>)}</div><div className="streak-line"><TrendingUp size={15} /><span>เรียนต่อเนื่อง <strong>{studyProgress.streak} วัน</strong>แล้ว เก่งมาก</span></div></section>
      </div>

      <section className="quick-actions"><Link href="/library" className="quick-action"><div className="quick-action-icon dark"><FolderOpen size={18} /></div><div><strong>เปิดคลังความรู้</strong><span>จัดการบทเรียนทั้งหมด</span></div><ArrowUpRight size={17} /></Link><Link href="/quiz/digestion" className="quick-action"><div className="quick-action-icon blue"><BrainCircuit size={18} /></div><div><strong>เริ่มทำแบบทดสอบ</strong><span>ลองวัดความเข้าใจสักหน่อย</span></div><ArrowUpRight size={17} /></Link></section>
    </div>
  );
}
