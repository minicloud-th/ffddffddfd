import type { Lesson, ProcessingStep, QuizQuestion, UploadedFile } from "@shared/types";
import { lessons } from "@/data/mockData";

export const processingSteps: ProcessingStep[] = [
  { title: "กำลังอ่านไฟล์", detail: "กำลังทำความเข้าใจเนื้อหาจากไฟล์ของคุณ" },
  { title: "กำลังแยกหัวข้อสำคัญ", detail: "กำลังหาแนวคิดหลักและจุดที่ควรจำ" },
  { title: "กำลังเรียบเรียงสรุป", detail: "กำลังจัดเนื้อหาให้เป็นภาษาที่อ่านง่าย" },
  { title: "กำลังเตรียมแบบทดสอบ", detail: "กำลังสร้างคำถามไว้ให้คุณลองทำ" },
  { title: "พร้อมเรียนแล้ว", detail: "สรุปและแบบทดสอบของคุณพร้อมแล้ว" },
];

const wait = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export function getLesson(id: string | undefined): Lesson {
  return lessons.find(lesson => lesson.id === id) ?? lessons[0];
}

export function formatFileSize(bytes: number) {
  if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export function fileToUpload(file: File): UploadedFile {
  const extension = file.name.split(".").pop()?.toUpperCase() ?? "FILE";
  return {
    id: `${file.name}-${file.lastModified}`,
    name: file.name,
    type: extension,
    size: formatFileSize(file.size),
    bytes: file.size,
    status: "ready",
  };
}

export async function simulateUpload(files: UploadedFile[], onProgress?: (progress: number) => void) {
  const total = Math.max(files.length, 1);
  for (let index = 0; index <= 5; index += 1) {
    await wait(180);
    onProgress?.(Math.min(100, Math.round((index / 5) * 100)));
  }
  return files.map(file => ({ ...file, status: "ready" as const, size: file.size, id: file.id })).slice(0, total);
}

export async function simulateProcessing(onStep?: (step: number) => void) {
  for (let step = 0; step < processingSteps.length; step += 1) {
    await wait(step === processingSteps.length - 1 ? 360 : 740);
    onStep?.(step);
  }
  return getLesson("digestion");
}

export async function askLesson(question: string, lesson: Lesson) {
  await wait(720);
  const normalized = question.toLowerCase();
  if (normalized.includes("สอบ") || normalized.includes("จำ")) {
    return {
      answer: `ถ้าจะเตรียมสอบเรื่อง${lesson.title} ให้เริ่มจาก “${lesson.keyPoints[0].title}” แล้วจำคู่คำสำคัญเหล่านี้: ${lesson.vocabulary.slice(0, 3).map(item => item.term).join(", ")} ลองทำแบบทดสอบท้ายบทต่อได้เลยนะ`,
      sources: ["สรุปบทเรียน", `ประเด็นสำคัญข้อ 1–${Math.min(3, lesson.keyPoints.length)}`],
    };
  }
  return {
    answer: `สรุปสั้น ๆ คือ ${lesson.summary} ถ้าอยากเข้าใจเพิ่ม ให้ลองอ่านหัวข้อ “${lesson.keyPoints[1]?.title ?? lesson.keyPoints[0].title}” แล้วดูตัวอย่างในคำศัพท์ด้านล่างได้เลย`,
    sources: ["สรุปบทเรียน", "รายละเอียดบทเรียน"],
  };
}

export function scoreQuiz(questions: QuizQuestion[], answers: Record<string, string>) {
  const correct = questions.filter(question => answers[question.id] === question.correctAnswer).length;
  return {
    correct,
    total: questions.length,
    percent: Math.round((correct / Math.max(questions.length, 1)) * 100),
  };
}
