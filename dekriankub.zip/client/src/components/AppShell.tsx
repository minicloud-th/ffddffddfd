import { Link, useLocation } from "wouter";
import {
  BarChart3,
  BookOpen,
  BrainCircuit,
  ChevronRight,
  CircleHelp,
  FilePlus2,
  FolderOpen,
  Home,
  Menu,
  Settings,
  Sparkles,
  Star,
  X,
} from "lucide-react";
import { useState, type ReactNode } from "react";

const navItems = [
  { href: "/", label: "หน้าแรก", icon: Home },
  { href: "/library", label: "คลังความรู้", icon: FolderOpen },
  { href: "/quiz/digestion", label: "แบบทดสอบ", icon: BrainCircuit },
  { href: "/progress", label: "ความคืบหน้า", icon: BarChart3 },
  { href: "/favorites", label: "รายการโปรด", icon: Star },
];

function Logo() {
  return (
    <Link href="/" className="brand-mark" aria-label="ไปหน้าแรก dekriankub">
      <span className="brand-dot" aria-hidden="true"><i /><i /></span>
      <span>dekriankub</span>
    </Link>
  );
}

function Navigation({ onNavigate }: { onNavigate?: () => void }) {
  const [location] = useLocation();
  return (
    <nav className="sidebar-nav" aria-label="เมนูหลัก">
      <p className="nav-heading">เรียนของฉัน</p>
      {navItems.map(item => {
        const Icon = item.icon;
        const isActive = item.href === "/" ? location === "/" : location.startsWith(item.href.split("/").slice(0, 2).join("/"));
        return (
          <Link key={item.href} href={item.href} onClick={onNavigate} className={`nav-link ${isActive ? "active" : ""}`}>
            <Icon size={18} strokeWidth={isActive ? 2.3 : 1.8} />
            <span>{item.label}</span>
            {isActive && <span className="nav-active-dot" aria-hidden="true" />}
          </Link>
        );
      })}
      <p className="nav-heading nav-heading-spaced">จัดการ</p>
      <Link href="/settings" onClick={onNavigate} className={`nav-link ${location.startsWith("/settings") ? "active" : ""}`}>
        <Settings size={18} strokeWidth={1.8} />
        <span>ตั้งค่า</span>
      </Link>
    </nav>
  );
}

export default function AppShell({ children }: { children: ReactNode }) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const closeMobile = () => setMobileOpen(false);

  return (
    <div className="app-frame">
      <aside className={`app-sidebar ${mobileOpen ? "mobile-open" : ""}`}>
        <div className="sidebar-top">
          <Logo />
          <button className="icon-button mobile-close" onClick={closeMobile} aria-label="ปิดเมนู"><X size={18} /></button>
        </div>
        <Link href="/upload" onClick={closeMobile} className="new-lesson-button">
          <FilePlus2 size={17} />
          <span>เริ่มบทเรียนใหม่</span>
        </Link>
        <Navigation onNavigate={closeMobile} />
        <div className="sidebar-bottom">
          <div className="mini-progress-card">
            <div className="mini-progress-head"><span>ความคืบหน้าวันนี้</span><Sparkles size={14} /></div>
            <strong>36 นาที</strong>
            <div className="progress-track"><span style={{ width: "72%" }} /></div>
            <p>อีกนิดเดียวก็ครบเป้าหมายแล้ว</p>
          </div>
          <div className="user-row">
            <div className="avatar">ม</div>
            <div><strong>น้องมิน</strong><span>ม.5 · เตรียมสอบ</span></div>
            <ChevronRight size={15} className="user-chevron" />
          </div>
          <button className="help-link"><CircleHelp size={16} /> ศูนย์ช่วยเหลือ</button>
        </div>
      </aside>
      {mobileOpen && <button className="mobile-backdrop" aria-label="ปิดเมนู" onClick={closeMobile} />}
      <div className="app-content">
        <header className="mobile-topbar">
          <button className="icon-button" onClick={() => setMobileOpen(true)} aria-label="เปิดเมนู"><Menu size={21} /></button>
          <Logo />
          <Link href="/settings" className="avatar small-avatar" aria-label="ไปตั้งค่า">ม</Link>
        </header>
        <main className="page-content">{children}</main>
        <nav className="mobile-bottom-nav" aria-label="เมนูบนมือถือ">
          {navItems.slice(0, 4).map(item => {
            const Icon = item.icon;
            return <Link key={item.href} href={item.href} className="mobile-nav-link"><Icon size={19} /><span>{item.label}</span></Link>;
          })}
        </nav>
      </div>
    </div>
  );
}
