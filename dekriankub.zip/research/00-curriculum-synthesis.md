# แผนข้อมูลหลักสูตรสำหรับ dekriankub

## 0) ขอบเขตและหลักฐาน

รายงานนี้สังเคราะห์ **เฉพาะ JSON ผลวิจัย 8 กลุ่มสาระที่ส่งมาในงานนี้** ไม่ได้เติมข้อเท็จจริงจากการค้นเว็บรอบใหม่ และไม่ตีความการเข้าถึงหน้าเว็บว่าเป็นสิทธิ์นำไปใช้ซ้ำ แก้ไข หรือแจกจ่ายได้

- ครอบคลุม ม.1–ม.6: ภาษาไทย, คณิตศาสตร์, วิทยาศาสตร์และเทคโนโลยี, สังคมศึกษา ศาสนา และวัฒนธรรม, สุขศึกษาและพลศึกษา, ศิลปะ, การงานอาชีพ และภาษาต่างประเทศ
- แยก **curriculum framework** (หลักสูตร/มาตรฐาน/ตัวชี้วัด/CEFR) ออกจาก **teachable content** (หน่วย บทเรียน กิจกรรม ใบงาน สื่อ และหลักฐานการเรียนรู้)
- ม.1–ม.3 ให้เก็บการอ้างอิงตัวชี้วัดรายชั้น; ม.4–ม.6 ให้เก็บตัวชี้วัดช่วงชั้นและฟิลด์ `school_sequence` เพราะลำดับหน่วยช่วงปลายเป็นข้อเสนอเพื่อทำ progression ไม่ใช่ลำดับบังคับเดียวกันทุกโรงเรียน
- ตัวเลข `source_count` ในรายงานและผลลัพธ์ท้ายงานนับ **URL entries ที่คืนมา 158 รายการ** (official 98, open-content 45, image 15) โดยยังไม่หัก URL ซ้ำระหว่างกลุ่มสาระ ไม่ใช่จำนวนใบอนุญาตหรือจำนวนไฟล์ที่นำไปเผยแพร่ได้

## 1) สรุปผู้บริหาร: สิ่งที่ควร seed

1. สร้าง ontology กลางให้ทุกกลุ่มใช้โครงเดียวกัน: `framework → standard/indicator → course → unit → lesson → activity → assessment_evidence`; แยก `asset` และ `rights_record` ออกจากเนื้อหา
2. เริ่มด้วยหน่วยแกนกลางระดับ ม.1–ม.3 ที่มีหลักฐานสอนได้จริงจาก DLTV/Project 14/ชุดกิจกรรม สพฐ. แล้วผูกกลับไปยังมาตรฐาน ไม่เอาชื่อบทหรือชื่อวิดีโอไปแทนตัวชี้วัด
3. สร้าง seed ม.4–ม.6 เป็น **proposed school progression** จากตัวชี้วัดช่วงชั้นและแหล่งเสริมที่พบ; ติดป้าย `proposed_seed` จนโรงเรียนตรวจหลักสูตรสถานศึกษา
4. เก็บแหล่งทางการแบบ deep-link และ metadata เป็นค่าเริ่มต้น; ไม่ mirror เอกสาร วิดีโอ ใบงาน หรือภาพที่ไม่มีใบอนุญาตเปิดชัดเจน
5. ใช้ Thai MOOC/OER เป็น micro-lesson, reading, case study หรือ enrichment หลังครูตรวจ alignment, ระดับวัย และใบอนุญาตรายคอร์ส/รายไฟล์
6. เปิดเผยสื่อรูปภาพได้เฉพาะเมื่อผ่าน rights gate: เก็บผู้สร้าง URL ต้นทาง URL ใบอนุญาต ข้อความ attribution และประวัติการดัดแปลงครบ
7. ทุก record ที่เข้าผลิตต้องมีผลลัพธ์การเรียนรู้ กิจกรรม หลักฐานการประเมิน แหล่งอ้างอิง และสถานะสิทธิ์ ไม่ seed เป็นเพียงชื่อหัวข้อ

## 2) ชุดข้อมูลและฟิลด์กลาง

### 2.1 Entity ที่แนะนำ

| Entity | หน้าที่ | ความสัมพันธ์หลัก |
|---|---|---|
| `curriculum_framework` | หลักสูตรแกนกลาง/มาตรฐาน/ตัวชี้วัด/CEFR | เป็นต้นทางของ `standard` และ `crosswalk` |
| `standard_indicator` | รหัสมาตรฐานและตัวชี้วัดรายชั้นหรือช่วงชั้น | ผูกกับ `learning_unit` หลายรายการได้ |
| `course` | รายวิชา/รายวิชาเพิ่มเติม/แทร็ก | อยู่ภายใต้กลุ่มสาระและ grade/grade_band |
| `learning_unit` | หน่วย seed ระดับโรงเรียน | มี `unit_key`, ผลลัพธ์ และลำดับโรงเรียน |
| `lesson` | บท/ตอน/ไมโครเลสสัน | อ้างแหล่ง DLTV, Project 14, Thai MOOC หรือ OER |
| `activity` | งานปฏิบัติ ใบงาน โครงงาน การแสดง การทดลอง หรือการพูด | มีวัสดุ ขั้นตอน ความปลอดภัย และหลักฐาน |
| `assessment` | วิธีตรวจผลและ rubric | ผูกกับ `assessment_evidence` |
| `asset` | ภาพ เสียง วิดีโอ แผนที่ แบบจำลอง หรือไฟล์ประกอบ | ต้องมี `rights_record` รายไฟล์ |
| `source` | URL และ provenance ของหน้า/เอกสารต้นทาง | ห้ามใช้ source แทน license |
| `rights_record` | ใบอนุญาต ข้อจำกัด และประวัติการตรวจ | เป็น gate ก่อนเผยแพร่หรือดัดแปลง |
| `crosswalk` | ความสัมพันธ์หน่วย ↔ มาตรฐาน/ตัวชี้วัด ↔ CEFR/ทักษะ | ระบุระดับความมั่นใจและสถานะ proposed/verified |

### 2.2 ฟิลด์ขั้นต่ำต่อ learning record

| หมวด | ฟิลด์ขั้นต่ำ | แนวทางเก็บ |
|---|---|---|
| ตัวตน | `subject_area`, `grade`, `grade_band`, `term`, `track`, `course_key`, `unit_key`, `lesson_key` | ม.1–ม.3 ใช้ grade รายชั้น; ม.4–ม.6 ใช้ทั้ง grade_band และระดับที่โรงเรียนจัด |
| กรอบ | `framework_id`, `strand`, `standard_code`, `indicator_code`, `curriculum_alignment`, `alignment_status` | ไม่รวมรหัสกรอบไว้ในชื่อหน่วย; แยก mapping เป็น record |
| ผลลัพธ์ | `learning_outcomes`, `knowledge`, `process_skills`, `attitudes`, `prerequisites` | ใช้ K-P-A เมื่อแหล่ง DLTV ให้ไว้; ถ้าเป็นข้อเสนอให้ระบุ `proposed` |
| การสอน | `activities`, `activity_type`, `materials`, `procedure`, `safety_notes`, `localization_notes` | กิจกรรมต้องไม่สื่อว่าผ่านการรับรองระดับชาติ หากเป็น seed ที่สังเคราะห์ |
| หลักฐาน | `assessment_evidence`, `assessment_method`, `rubric`, `expected_artifact` | เก็บชิ้นงาน/การแสดง/รายงาน/โค้ด/portfolio ไม่ใช่ข้อสอบจำอย่างเดียว |
| ที่มา | `source_url`, `source_type`, `source_title`, `source_publisher`, `creator`, `accessed_at`, `last_checked` | ใช้ deep-link และสรุปข้อเท็จจริงสั้น ๆ แทนการเก็บสำเนาทั้งหมด |
| สิทธิ์ | `license_status`, `license`, `license_url`, `raw_license_text`, `attribution`, `can_modify`, `can_redistribute`, `commercial_allowed`, `do_not_republish`, `adaptation_allowed` | ให้สิทธิ์ระดับ asset/file เมื่อหน้าเว็บรวมหลายไฟล์ |
| การปฏิบัติการ | `status`, `reviewer`, `reviewed_at`, `school_sequence`, `version`, `change_log` | แยก `official`, `evidence_based`, `proposed_seed`, `retired` |

สถานะสิทธิ์ที่ควรรองรับและใช้ให้สอดคล้องกับหลักฐาน ได้แก่ `verified_open`, `permission_required`, `unknown`, `official-reference`, `official-restricted`, `teaching-only`, `per-file-license-check`, `CC-BY`, `CC-BY-SA`, `CC-BY-NC-SA`, `CC-BY-NC-ND`, และ `do_not_republish` โดยต้องเก็บข้อความ license เดิมประกอบ ไม่ใช้เพียง label เดียว

### 2.3 รูปแบบ crosswalk

```text
framework_id
  └─ standard_code / indicator_code
       └─ course_key + grade/grade_band
            └─ unit_key
                 └─ lesson_key / activity_key
                      └─ assessment_evidence
                           └─ source_url + rights_record
```

ให้ `crosswalk` มี `alignment_status = verified | proposed | needs_review` และ `evidence_note` ว่าการ mapping มาจากกรอบทางการ แผน DLTV/Project 14 หรือการจัดหน่วยสังเคราะห์ ไม่ให้ชื่อบทจากแหล่งสอนถูกตีความเป็นตัวชี้วัดแห่งชาติ

## 3) ชุดวิชาที่ควร seed

### 3.1 ตารางภาพรวม 8 กลุ่มสาระ

| รหัส | ชุดวิชา | กรอบที่ต้อง seed | เนื้อหาสอนได้จริง/seed ที่ควรเริ่ม | หลักฐานการเรียนรู้ที่เหมาะ |
|---|---|---|---|---|
| `TH` | ภาษาไทย | ท 1.1 อ่าน, ท 2.1 เขียน, ท 3.1 ฟัง-ดู-พูด, ท 4.1 หลักภาษา, ท 5.1 วรรณคดี/วรรณกรรม | ม.1 อ่านออกเสียง-จับใจความ-สรุปและงานเขียน; ม.2 อ่านสื่อร่วมสมัย/แยกข้อเท็จจริง-ข้อคิดเห็น/โฆษณา; ม.3 อ่านเชิงวิจารณ์/สารโน้มน้าว; ม.4–ม.6 ตีความ งานวิชาการ วิเคราะห์วิจารณ์ สังเคราะห์ และเขียนเชิงวิชาการ/ข้อเสนอ | คำตอบอ่านจับใจความ, บทสรุป, เรียงความ/รายงาน, วิเคราะห์โฆษณาหรือวรรณคดี, การพูด/โต้แย้ง และ portfolio การเขียน |
| `MA` | คณิตศาสตร์ | 3 สาระ: จำนวนและพีชคณิต; การวัดและเรขาคณิต; สถิติและความน่าจะเป็น พร้อมทักษะกระบวนการ 5 ด้าน | ม.1 จำนวนเต็ม เลขยกกำลัง สมการ อัตราส่วน กราฟ รูป 2/3 มิติ และข้อมูล; ม.2 จำนวนจริง พหุนาม พีทาโกรัส การแปลง และสถิติ; ม.3 อสมการ สมการกำลังสอง ฟังก์ชัน ความคล้าย วงกลม ควอร์ไทล์ และความน่าจะเป็น; ม.4–ม.6 เซต ตรรกศาสตร์ การนับ ฟังก์ชัน ลำดับ/อนุกรม ตรีโกณมิติ เมทริกซ์ เวกเตอร์ สถิติ และแคลคูลัสเบื้องต้น | วิธีทำพร้อมเหตุผล, แบบจำลอง/กราฟ, รายงานข้อมูล, การพิสูจน์หรือให้เหตุผล, โครงงานความน่าจะเป็น และการนำเสนอการวิเคราะห์ |
| `SC` | วิทยาศาสตร์และเทคโนโลยี | กรอบวิทยาศาสตร์ตามหลักสูตรและสาระวิทยาการคำนวณ; แยก framework/indicator จากบท Project 14 | ม.1 สาร สิ่งมีชีวิต พืช ความร้อน ลมฟ้าอากาศ และแนวคิดเชิงนามธรรม/Python/Scratch; ม.2 สารละลาย ร่างกาย แรง งานพลังงาน โลก และระบบ/เครือข่าย; ม.3 พันธุศาสตร์ คลื่น ไฟฟ้า ระบบนิเวศ และแอป/ข้อมูล/IoT; ม.4–ม.6 ชีวภาพ กายภาพ โลก-ดาราศาสตร์ การเรียง/ค้นข้อมูล วิทยาการข้อมูล การทำข้อมูลเป็นภาพ AI และพลเมืองดิจิทัล | บันทึกการทดลองและความปลอดภัย, รายงานข้อมูล/กราฟ, แบบจำลอง, โค้ดและคำอธิบาย algorithm, data story, โครงงาน และหลักฐาน digital citizenship |
| `SO` | สังคมศึกษา ศาสนา และวัฒนธรรม | ส 1 ศาสนา, ส 2 หน้าที่พลเมือง, ส 3 เศรษฐศาสตร์, ส 4 ประวัติศาสตร์, ส 5 ภูมิศาสตร์ | ม.1–ม.3 ศาสนา/จริยธรรม สิทธิ-กฎหมาย การเมือง เศรษฐศาสตร์ชีวิตประจำวัน ประวัติศาสตร์เอเชีย/ไทย และภูมิศาสตร์ทวีปต่าง ๆ; ม.4–ม.6 จริยธรรมร่วมสมัย นิติธรรม เศรษฐศาสตร์จุลภาค-มหภาค วิธีวิทยาประวัติศาสตร์ ภูมิสารสนเทศ นโยบายสาธารณะ การเงิน/ภาษี/การลงทุน สิ่งแวดล้อม ภูมิอากาศ และ SDGs | วิเคราะห์หลักฐาน, แผนที่/ข้อมูลภูมิศาสตร์, policy brief, argument พร้อมแหล่งอ้างอิง, timeline, case study และการอภิปรายพลเมือง |
| `HP` | สุขศึกษาและพลศึกษา | พ 1.1 พัฒนาการ, พ 2.1 ชีวิต/ครอบครัว, พ 3.1–พ 3.2 การเคลื่อนไหว/กีฬา, พ 4.1 สุขภาพ, พ 5.1 ความปลอดภัย | ม.1–ม.3 พัฒนาการวัยรุ่น เพศวิถี โรค/STI สารเสพติด ปฐมพยาบาล โภชนาการ สมรรถภาพ และกีฬา; ม.4–ม.6 ระบบอวัยวะ สุขภาพจิต การนอน การสื่อสาร/ต่อรอง/ปฏิเสธ วิทยาศาสตร์การกีฬา สุขภาพชุมชน ฉุกเฉิน และโครงงานรู้เท่าทันสุขภาพ | แผนสุขภาพ, การสาธิต/ฝึกทักษะอย่างปลอดภัย, บันทึกสมรรถภาพ, แผนรณรงค์, การตัดสินใจจากสถานการณ์ และโครงงาน โดยมีผู้ทบทวนวิชาการ |
| `AR` | ศิลปะ | ศ 1.1–ศ 1.2 ทัศนศิลป์, ศ 2.1–ศ 2.2 ดนตรี, ศ 3.1–ศ 3.2 นาฏศิลป์ | ม.1–ม.3 ทัศนธาตุ/การออกแบบ/วิจารณ์, ร้อง-บรรเลง/โน้ต/วง, นาฏยศัพท์/การแสดง/งาน stagecraft; ม.4–ม.6 อ่านภาพ ทฤษฎีสี ประวัติศิลป์ สื่อผสม/ดิจิทัล ประพันธ์/เรียบเรียง ผลิตการแสดง วิเคราะห์บริบท และ portfolio | ผลงาน/portfolio, sketch/process log, การร้องหรือบรรเลง, แผนและวิดีโอการแสดง, artist statement, critique และหลักฐานเคารพวัฒนธรรม/สิทธิ์เพลงภาพ |
| `CA` | การงานอาชีพ | กรอบมาตรฐาน/ตัวชี้วัดการงานอาชีพ แยกจากกิจกรรม/อาชีพเฉพาะถิ่น | ม.1 บ้าน งานประดิษฐ์ ปลูกต้นอ่อน เสื้อผ้าและอาชีพ; ม.2 ซ่อมเสื้อผ้า ขยายพันธุ์พืช ประปา ใช้ซ้ำ; ม.3 อาหาร เครื่องดื่ม แปรรูป งานไม้ เพิ่มมูลค่า/OTOP; ม.4–ม.6 สำรวจอาชีพ เกษตรยั่งยืน ผลิตภัณฑ์ชุมชน ต้นทุน-ราคา-สต็อก การตลาดดิจิทัล CV สัมภาษณ์ และแผนศึกษาต่อ/ทำงาน | ชิ้นงาน/ต้นแบบ, ขั้นตอนและต้นทุน, business/product pitch, แฟ้มสะสมงาน CV, การสัมภาษณ์จำลอง และโครงงานอาชีพที่มี safety notes |
| `LA` | ภาษาต่างประเทศ | ต 1–ต 4 และ CEFR; อังกฤษเป็นแกนกลาง ส่วนจีน ญี่ปุ่น เกาหลี ฝรั่งเศสเป็นรายวิชาเพิ่มเติม/หลักสูตรสถานศึกษา | อังกฤษ ม.1–ม.3 identity/home/recreation/health/food/travel/technology/environment/occupations; ม.4–ม.6 ไล่ A2→B1 ผ่านสื่อ วิชาการ การท่องเที่ยว อาชีพ การนำเสนอ วิจัย และ portfolio; ภาษาที่สองไล่จากอักษร/เสียง แนะนำตน ไปสู่บริการ อาชีพ และ capstone ข้ามวัฒนธรรม | CEFR can-do, listening/speaking tasks, reading response, writing, survey/graph, review/showcase/design pitch และ portfolio; เพิ่ม `script_or_sound` กับ pattern เฉพาะภาษา |

### 3.2 รายละเอียดการจัด seed ตามกลุ่มสาระ

#### ภาษาไทย (`TH`)

- เก็บกรอบ ท 1.1–ท 5.1 เป็น framework records และอย่าใช้ชื่อวรรณคดี/ตอน DLTV แทนมาตรฐาน
- Seed ที่มีหลักฐานสอนได้จริง: ม.1 งานเขียนและโอ้เอ้วิหารราย; ม.2 อ่านสื่อร่วมสมัย สรุป สารโน้มน้าว และโฆษณา; ม.3 พระบรมราโชวาท สารโน้มน้าว และโฆษณาท้องถิ่น; คู่มือ ม.2 เป็นตัวอย่างอ่าน-เขียน-หลักภาษา-โคลงภาพพระราชพงศาวดาร
- Thai MOOC 00754 มี 7 โมดูลอ่าน (อ่านออกเสียง ประเภทงานเขียน จับใจความ สรุป แสดงทรรศนะ ตีความ) ให้เก็บเป็นคลัง micro-lesson เสริม ไม่ map ตรงเป็นหลักสูตร ม.1–ม.6
- ม.4–ม.6 seed เน้นอ่านบทความ/งานวิชาการ เปรียบเทียบข้อโต้แย้ง เขียนวิเคราะห์-สังเคราะห์ งานวิชาการ/โครงงาน และวิจารณ์วรรณคดีเชื่อมบริบท

#### คณิตศาสตร์ (`MA`)

- แยก `strand` จำนวนและพีชคณิต / การวัดและเรขาคณิต / สถิติและความน่าจะเป็น และเก็บทักษะกระบวนการ 5 ด้านเป็นฟิลด์ร่วม
- Seed ระดับหน่วย เช่น ม.2–สถิติ–ฮิสโทแกรม ให้ผูก mapping ที่เกี่ยวข้อง เช่น ค 3.1; หน่วยความน่าจะเป็นอาจ map ทั้ง ค 1.1/ค 3.2 ตามบริบท ต้องมี `evidence_note`
- เก็บ prerequisites ชัดเจน โดยเฉพาะจำนวนจริง/พหุนาม → สมการกำลังสอง, สถิติพื้นฐาน → การวิเคราะห์ข้อมูล, และฟังก์ชัน → ตรีโกณมิติ/แคลคูลัส
- สื่อ GeoGebra, Commons, OpenStax และ Thai MOOC เป็น enrichment แยก rights จาก core framework; อย่าใช้ free access เป็นค่า `open`

#### วิทยาศาสตร์และเทคโนโลยี (`SC`)

- ใช้ hierarchy `domain > grade > course > unit > chapter > lesson > activity > assessment` และมี `framework_indicator_id` แยกจาก `content_id`
- วิทยาศาสตร์ต้องมีวัสดุ ขั้นตอน ความปลอดภัย การบันทึกข้อมูล หลักฐานที่คาดหวัง และ rubric; วิทยาการคำนวณต้องมีภาษา/เครื่องมือ input-output algorithm code privacy และ digital citizenship
- Project 14 ใช้เป็นบท/lesson source หลัง mapping กลับมาตรฐาน; DLTV ใช้เป็น lesson-plan/activity record; Thai MOOC/OER ใช้หลังตรวจ license รายคอร์ส/รายไฟล์
- ม.4–ม.6 ต้อง map กลับตัวชี้วัดช่วงชั้นและลำดับรายวิชาจริงของโรงเรียน ไม่อ้างว่าเป็น DLTV ม.ปลาย เพราะหลักฐานที่คืนมายังไม่พบชุด DLTV ม.4–ม.6 ในหน้าที่ตรวจ

#### สังคมศึกษา (`SO`)

- taxonomy กลางคือ ส 1–ส 5 และทุก unit ต้องมี `framework_refs`, `provenance`, `rights_status`
- รายการหน่วย ม.1–ม.6 ในหลักฐานเป็น proposed seed ไม่ใช่ลำดับบังคับของทุกโรงเรียน; ใช้แหล่ง DLTV เป็นตัวอย่างกิจกรรม ไม่ใช่การรับรองลำดับชาติ
- แยก evidence ประเภทหลักฐานทางประวัติศาสตร์ แผนที่/ข้อมูล ภาวะเศรษฐกิจ และการให้เหตุผลเชิงพลเมือง เพื่อให้ประเมินการคิด ไม่ใช่จำเหตุการณ์/คำนิยามอย่างเดียว
- IPST ที่พบในชุดนี้เป็นเอกสารอบรมวิทยาการคำนวณ/บริบทการปรับหลักสูตร ไม่ใช่คลังบทเรียนสังคมศึกษาโดยตรง จึงไม่ label เป็น content หลักจนกว่าจะตรวจ resource รายการนั้น

#### สุขศึกษาและพลศึกษา (`HP`)

- ใช้ `unit_id` รูปแบบ M1-U01 ถึง M6-U05 เป็น seed convention; ม.4–ม.6 เป็นข้อเสนอจากตัวชี้วัดช่วงชั้น
- record สุขภาพต้องมีผู้ทบทวนวิชาการ วันที่ทบทวน และข้อความว่าไม่แทนการวินิจฉัยแพทย์ โดยเฉพาะปฐมพยาบาล ยา สารเสพติด เพศศึกษา และโภชนาการ
- เพศศึกษาต้องรองรับ consent, privacy, non-stigmatizing language, referral และความปลอดภัยจากความรุนแรง; พลศึกษาต้องเก็บความหนัก อุปกรณ์ warm-up/cool-down และการปรับกิจกรรม

#### ศิลปะ (`AR`)

- ใช้ ontology 6 มาตรฐาน สพฐ. แล้วแตกเป็น 3 แขนง: ทัศนศิลป์ ดนตรี นาฏศิลป์
- skills ข้ามแขนง: `observe/listen`, `practice/create`, `perform/present`, `analyze/critique`, `connect_culture`, `reflect/conserve`; หลักฐานควรเป็น process + product ไม่ใช่ข้อสอบจำ
- DLTV ม.1–ม.3 และโครงสร้างทัศนศิลป์ ม.6 เป็นจุดเริ่ม seed; Thai MOOC/Pressbooks/OpenStax เป็นเสริม; ภาพ เสียง เพลง ท่ารำ และบุคคลที่สามต้อง rights check รายชิ้น

#### การงานอาชีพ (`CA`)

- เก็บ `learning_outcome_KPA`, `activity_type`, `safety_notes`, `localization_notes`, ต้นทุน/ราคา/สต็อก และ `evidence_type`
- DLTV เป็นตัวอย่างกิจกรรม ม.1–ม.3 เพราะหน้าตอนมีสาระสำคัญ ตัวชี้วัด จุดประสงค์ K-P-A การวัดผล ใบงาน และใบความรู้
- ม.4–ม.6 เป็นข้อเสนอจากช่วงชั้นและแหล่งเปิด ต้องปรับตามบริบทท้องถิ่น; งานช่าง เกษตร อาหาร และเครื่องมือไฟฟ้าต้องมีผู้กำกับครูและข้อควรระวัง
- เนื้อหากฎหมาย ราคา และเกษตรต้องมีวันที่ตรวจและบริบทพื้นที่ ไม่ควรทำเป็นข้อมูลถาวรโดยไม่มี `last_checked`

#### ภาษาต่างประเทศ (`LA`)

- อังกฤษเป็นวิชาพื้นฐานในแกนกลาง; จีน ญี่ปุ่น เกาหลี ฝรั่งเศสต้องติดป้าย `additional_course` หรือ `school_curriculum` ไม่ใช่ core ทุกโรงเรียน
- หลักฐาน DLTV ที่ชัด: ม.1 My Home (คำศัพท์บ้าน ฟังจับหัวข้อ พูด ใบงาน), ม.2 Recreation (กิจกรรมยามว่าง ความถี่ การพูด ใบงาน); ชุดกิจกรรม สพฐ. ม.1 มี 8 หน่วย รวม 120 ชั่วโมง และ ม.3 มี 8 หน่วยแบ่งภาคเรียนละ 4 หน่วย พร้อมภาระงาน survey/graph/review/showcase/design pitch
- ทุก unit ต้อง crosswalk `ต 1–ต 4 ↔ CEFR can-do ↔ assessment evidence`; ภาษาที่สองเพิ่ม `script_or_sound` และ pattern เฉพาะภาษา เช่น พินอิน/วรรณยุกต์ kana, Hangul/받침 หรือ gender/agreement ของฝรั่งเศส

## 4) แหล่งที่ใช้ได้และวิธีใช้

### 4.1 Source tiers

| Tier | แหล่งในหลักฐาน | ใช้สำหรับ | สิ่งที่ห้ามสรุปเกินหลักฐาน |
|---|---|---|---|
| A: กรอบ/อ้างอิงทางการ | สพฐ./Academic OBEC, IPST, Project 14, SciMath, ชุดกิจกรรม สพฐ., DOAE | ยืนยันกรอบ มาตรฐาน ตัวชี้วัด ชื่อหน่วย และ metadata | การเปิดอ่าน/ดาวน์โหลดไม่ได้แปลว่า CC, OER หรือให้สิทธิ์ rehost/ดัดแปลง |
| B: teachable evidence | DLTV แผน/ตอน/ใบงาน/คู่มือ, หน่วยกิจกรรมที่หน้าเว็บแสดง | แตก unit/lesson/activity, จุดประสงค์ K-P-A, งานและการวัดผล | ไม่ตีความเป็นใบอนุญาตเปิด; ค่าเริ่มต้นคือ deep-link และไม่ mirror |
| C: open/enrichment | Thai MOOC, OpenLearn, OpenStax, Pressbooks, OER Learn.in.th/OER Commons | micro-lesson, reading, case study, enrichment หรือกิจกรรมเสริม | ต้องอ่าน license รายคอร์ส/รายไฟล์และข้อยกเว้นบุคคลที่สาม; ไม่คัดลอกทั้งเล่มอัตโนมัติ |
| D: media/assets | Wikimedia Commons, Openverse, แผนที่/ภาพ/กราฟ และ GeoGebra | ภาพ/เสียง/interactive asset ที่ตรวจรายไฟล์ | license ของหมวดหรือ directory ไม่แทน license ของไฟล์; ต้องเก็บ creator/URL/license/attribution |

### 4.2 Source inventory จากหลักฐานที่คืนมา

| กลุ่ม | Official/กรอบอ้างอิง | Open/enrichment | Image/asset | URL entries รวม |
|---|---:|---:|---:|---:|
| ภาษาไทย | 11 | 2 | 0 | 13 |
| คณิตศาสตร์ | 16 | 5 | 3 | 24 |
| วิทยาศาสตร์และเทคโนโลยี | 20 | 5 | 0 | 25 |
| สังคมศึกษา | 10 | 5 | 2 | 17 |
| สุขศึกษาและพลศึกษา | 12 | 9 | 2 | 23 |
| ศิลปะ | 9 | 6 | 4 | 19 |
| การงานอาชีพ | 9 | 8 | 2 | 19 |
| ภาษาต่างประเทศ | 11 | 5 | 2 | 18 |
| **รวม** | **98** | **45** | **15** | **158** |

#### Official sources ที่ควรลง source registry

- ภาษาไทย: เอกสารกรอบหลักสูตร/ตัวชี้วัด สพฐ. (`academic.obec.go.th`), DLTV ม.1–ม.3, คู่มือ DLTV, OBEC Content Center และ IPST curriculum/news
- คณิตศาสตร์: IPST curriculum/เอกสารกรอบ, Project 14 หนังสือ ม.1–ม.3 และ ม.4–ม.6 basic/advanced, DLTV ม.1–ม.3 และ IPST content detail
- วิทยาศาสตร์และเทคโนโลยี: IPST curriculum, เอกสาร สพฐ., SciMath วิทยาศาสตร์/เทคโนโลยี, Project 14 วิทยาศาสตร์และวิทยาการคำนวณ ม.1–ม.6
- สังคมศึกษา: เอกสารกรอบ/ตัวชี้วัด สพฐ., DLTV ม.1–ม.3, เอกสารบริบท IPST/Oho และแหล่งทางการที่คืนมาในชุดนี้
- สุขศึกษาและพลศึกษา: เอกสาร สพฐ., DLTV ม.1–ม.3, OBEC Content Center และแหล่งทางการที่คืนมา; Project 14 ไม่ใช่คลัง HPE โดยตรง
- ศิลปะ: เอกสาร สพฐ./Academic OBEC, IPST curriculum, DLTV ทัศนศิลป์ ดนตรี นาฏศิลป์ และโครงสร้างทัศนศิลป์ ม.6
- การงานอาชีพ: เอกสารกรอบ สพฐ., DLTV ม.1–ม.3, My IPST และสื่อ DOAE
- ภาษาต่างประเทศ: เอกสาร สพฐ./กระทรวงศึกษาธิการ, ชุดกิจกรรมภาษาอังกฤษ, My IPST, DLTV ม.1–ม.3 และตอน My Home/Recreation

#### Open/enrichment sources ที่มีหลักฐานสิทธิ์หรือเงื่อนไขเฉพาะ

- **ภาษาไทย:** Thai MOOC UP 00754 ระบุ CC BY-NC-SA 4.0; ใช้ไม่เชิงพาณิชย์ ให้เครดิต ระบุการเปลี่ยนแปลง และเผยแพร่ต่อด้วยเงื่อนไขเดียวกัน; ตรวจสื่อฝัง/ตัวบทบุคคลที่สามแยก
- **คณิตศาสตร์:** Thai MOOC SSRU 007, SUT 001 ระบุ CC BY-SA-NC/CC BY-NC-SA; MU 004 มีชื่อใบอนุญาตไม่มาตรฐานต้องตรวจ; OpenStax Contemporary Mathematics CC BY-NC-SA 4.0; หน้า Creative Commons เป็นดัชนีค้นต่อ ไม่ใช่ license ของทุก resource
- **วิทยาศาสตร์และเทคโนโลยี:** Thai MOOC 00722 ที่ตรวจระบุ CC BY-NC-SA; OER Learn.in.th ระบุ license โครงการ CC BY-SA 4.0 แต่ตรวจ metadata ราย item; My IPST/Project 14 เป็นแหล่งอ้างอิง/สื่อของหน่วยงาน ไม่ใช่ open โดยอัตโนมัติ
- **สังคมศึกษา:** Thai MOOC CMU 00073 และ TU 00011 ระบุ CC BY-NC-SA; OpenStax Economics/World History CC BY-NC-SA 4.0 พร้อมตรวจภาพ/โลโก้/ส่วนประกอบ และหลักฐานระบุข้อห้าม ingest เข้า LLM โดยไม่มีอนุญาต
- **สุขศึกษาและพลศึกษา:** Thai MOOC SSRU00622, CRRU020, WU00766, PSU00526, WU00784 ระบุ CC BY-NC-SA; OpenLearn ระบุ CC BY-NC-SA 4.0; OpenStax Anatomy & Physiology 2e CC BY-NC-SA 4.0; ตรวจสื่อฝังรายชิ้น
- **ศิลปะ:** Thai MOOC SU 00689/00690 CC BY-NC-SA; Exploring the Arts CC BY 4.0; OpenStax Anthropology of the Arts CC BY-NC-SA 4.0; OER Commons เป็นคลังค้นต่อ ต้องตรวจ resource รายรายการ
- **การงานอาชีพ:** Thai MOOC SRU 00613, RMUTT 00544, STOU 00658, TU 00028, PIM 00500, SU 00686 ระบุ CC BY-NC-SA; ONDE 00484 ระบุ CC BY-NC-ND จึงแชร์ต้นฉบับแบบไม่เชิงพาณิชย์พร้อมเครดิตได้ แต่ห้ามดัดแปลงตามหลักฐานที่คืนมา
- **ภาษาต่างประเทศ:** Thai MOOC UP001 และ NPRU004 ระบุ CC BY-NC-SA; Openverse/Wikimedia เป็น directory ที่ต้องตรวจ license ราย file

## 5) รูปภาพและ asset plan

ไม่มี image source ที่คืนมาสำหรับภาษาไทยและวิทยาศาสตร์/เทคโนโลยี จึงไม่ควรสร้างรายการภาพขึ้นเองใน seed ชุดนี้

| กลุ่ม | แหล่งภาพที่คืนมา | สถานะ/วิธีใช้ |
|---|---|---|
| คณิตศาสตร์ | Wikimedia Mathematical diagrams; Chart and graph resources; GeoGebra | Commons/OWID ต้องตรวจ license ต้นทางรายไฟล์; GeoGebra ระบุ non-commercial และ attribution ตามหลักฐาน |
| สังคมศึกษา | Wikimedia Atlas of Thailand; Thailand six regions.svg | ไฟล์ Thailand six regions.svg ระบุ CC BY-SA 3.0; เก็บเครดิต URL license การแก้ไข และ share-alike; structured data กับไฟล์อาจมีเงื่อนไขต่างกัน |
| สุขศึกษา/พลศึกษา | Wikimedia `PHYSICAL FITNESS and HEALTH title image.png`; Category:Physical education | ไฟล์ title image ระบุ CC0 1.0 แต่ยังควรเก็บ creator/source/ประวัติไฟล์; หมวดหมู่ไม่ใช่ license เดียว |
| ศิลปะ | Thai traditional dance.jpg; Ching musical instrument.jpg; Thai taphon.jpg; Musical instruments of Thailand | สองไฟล์แรกระบุ CC BY-SA 3.0, Thai taphon ระบุ public domain ตามหลักฐาน; หมวดเครื่องดนตรีต้องตรวจรายไฟล์ |
| การงานอาชีพ | Wikimedia Agriculture; Tools | เป็นหมวดรวม ต้องเปิดหน้าไฟล์จริง ตรวจผู้สร้าง เครดิต และ license ก่อนใช้ |
| ภาษาต่างประเทศ | Openverse; Wikimedia Commons Licensing | ใช้เป็นช่องค้น ไม่ใช่หลักฐาน license ของ asset ใด asset หนึ่ง; เก็บ author/source/license URL ทุกภาพ/เสียง |

Schema สำหรับ asset ควรบังคับ `asset_id`, `source_url`, `creator`, `owner`, `license`, `license_url`, `attribution_text`, `downloaded_at`, `modified`, `modification_note`, `can_redistribute`, `commercial_allowed`, `rights_checked_by`, `last_checked` และ `do_not_republish` หากยังไม่ผ่าน gate

## 6) ข้อจำกัดลิขสิทธิ์และ policy gate

1. **Official ≠ open:** เอกสาร สพฐ./IPST/Project 14/SciMath/My IPST/DOAE ที่เข้าถึงได้จากเว็บทางการไม่ได้แสดง CC ครอบคลุมทุกไฟล์ในหน้าที่ตรวจ ให้เก็บ URL ชื่อเรื่อง ผู้เผยแพร่ สรุปสั้น และ alignment; ไม่ rehost/คัดลอกทั้งไฟล์โดยอัตโนมัติ
2. **DLTV:** หลักฐานระบุใช้เพื่อจัดการเรียนการสอนตามการออกอากาศ และห้ามดาวน์โหลด คัดลอก ทำซ้ำ ดัดแปลง หรือเผยแพร่เพื่อส่วนตัว/แสวงหาผลประโยชน์ ค่าเริ่มต้นของ record คือ `rights_status=official-restricted` หรือ `teaching-only`, `do_not_republish=true`; เก็บ deep-link/metadata/สรุปที่เขียนใหม่
3. **CC ต้องทำตามเงื่อนไข:** CC BY ต้องให้เครดิต; CC BY-SA ต้อง share-alike; CC BY-NC ใช้ไม่เชิงพาณิชย์; CC BY-ND ห้ามดัดแปลง; CC BY-NC-SA ใช้ไม่เชิงพาณิชย์และเผยแพร่ derivative ด้วยเงื่อนไขเดียวกันตามใบอนุญาตที่ระบุ
4. **รายคอร์ส/รายไฟล์:** Thai MOOC, OpenStax, OpenLearn, OER และ Commons อาจมีภาพ เสียง ตัวบท โลโก้ หรือองค์ประกอบบุคคลที่สาม ต้องตรวจแยก แม้หน้าคอร์สหรือโครงการประกาศ CC
5. **OpenStax:** หลักฐานคณิตศาสตร์และสังคมศึกษาระบุข้อห้ามนำเนื้อหาไปฝึกหรือป้อนโมเดล AI โดยไม่มีอนุญาต; policy ของระบบต้องเก็บข้อจำกัดนี้ใน `rights_record` และไม่ ingest เนื้อหา OpenStax เข้า pipeline AI โดยอัตโนมัติ
6. **Attribution bundle:** ทุกการแสดงผลสาธารณะต้องสร้าง attribution จากชื่อผู้สร้าง ชื่อผลงาน URL ต้นทาง URL license และข้อความการดัดแปลง; ควรเก็บ raw license/หลักฐานพร้อมวันที่ตรวจ
7. **สิทธิ์บุคคลและความปลอดภัย:** ศิลปะต้องตรวจสิทธิ์เพลง/ภาพและความเคารพเจ้าของวัฒนธรรม; สุขศึกษาและพลศึกษาต้องตรวจความปลอดภัย/ความเป็นส่วนตัว; การงานอาชีพต้องตรวจความเสี่ยงเครื่องมือ/อาหาร/สารเคมี; วิทยาศาสตร์ต้องมี safety record

## 7) ลำดับ rollout ที่แนะนำ

### Phase 0 — Schema, provenance และ rights gate

- สร้าง entity และฟิลด์ใน §2 ก่อนนำเนื้อหาเข้า
- นำ URL entries ทั้ง 158 รายการเข้า `source` registry แบบยังไม่คัดลอกสื่อ
- ทำ status normalization (`official-reference`, `official-restricted`, `permission_required`, `verified_open`, `per-file-license-check`, `unknown`)
- ทำ validation บังคับ `source_url`, `last_checked`, `curriculum_alignment`, `license_status`, `attribution` และ `alignment_status`

**จุดผ่าน:** ทุก record รู้ว่าเป็นกรอบหรือ content, มีแหล่งที่มา และไม่กล่าวอ้างสิทธิ์เกินหลักฐาน

### Phase 1 — Core teachable seeds ม.1–ม.3

- ภาษาไทย: DLTV ม.1–ม.3 + คู่มือ ม.2 + Thai MOOC reading เป็น micro-lesson
- คณิตศาสตร์: Project 14 ม.1–ม.3 และ DLTV ม.1–ม.3; เริ่มจากจำนวน/สมการ/เรขาคณิต/สถิติที่มี prerequisites ชัด
- วิทยาศาสตร์และเทคโนโลยี: Project 14 ม.1–ม.3, DLTV lesson/activity และกิจกรรมวิทย์/โค้ดที่มี safety/evidence
- ภาษาต่างประเทศ: ชุดกิจกรรม สพฐ. และ DLTV My Home/Recreation พร้อม ต 1–ต 4 ↔ CEFR

**จุดผ่าน:** หน่วยแต่ละรายการมี learning outcome, activity, assessment evidence และ mapping; DLTV ยังเป็น deep-link ไม่ใช่ไฟล์ที่ mirror

### Phase 2 — Core framework และ teachable seeds ของสังคม/สุขศึกษา/ศิลปะ/การงาน

- สังคม: เริ่มจาก 5 strands และ DLTV ม.1–ม.3; tag proposed seed ให้หน่วยที่ไม่ได้ยืนยันเป็นลำดับทางการ
- สุขศึกษา/พลศึกษา: เริ่มหน่วยที่มี safety/referral/reviewer; แยกสุขภาพกับกิจกรรมกีฬาและเก็บ evidence ของทักษะ
- ศิลปะ: เริ่มจาก DLTV ม.1–ม.3, โครงสร้างทัศนศิลป์ ม.6 และ skills ข้ามแขนง; asset gate เข้มกับเพลง/ภาพ/วิดีโอ
- การงาน: เริ่มกิจกรรม DLTV ม.1–ม.3 พร้อม safety, localization และหลักฐานชิ้นงาน/ต้นทุน

**จุดผ่าน:** มีผู้ตรวจเนื้อหาเฉพาะทางตามความเสี่ยง และไม่มี asset ที่ license ยัง `unknown` ปรากฏเป็น public asset

### Phase 3 — ม.4–ม.6 progression และ capstone

- สร้าง grade-band records สำหรับทุกกลุ่มสาระ แล้วให้โรงเรียนกำหนด `school_sequence` และ term เอง
- ทำ capstone ที่เชื่อมทักษะ: รายงาน/วิจัย/ข้อเสนอ, data story, portfolio ศิลปะ/ภาษา, health/community project และ career plan
- วิทยาศาสตร์/คณิตศาสตร์/ภาษาอังกฤษต้องเก็บ prerequisites และความก้าวหน้า; ภาษาอังกฤษผูก A2 → B1 ตามหลักฐานที่คืนมา
- ใช้ `proposed_seed` จนมีการตรวจหลักสูตรสถานศึกษา ไม่ label ว่าเป็นแผน DLTV ม.ปลาย

**จุดผ่าน:** ทุกหน่วยปลายมี crosswalk ช่วงชั้น, prerequisite, expected artifact, rubric และ reviewer ของโรงเรียน

### Phase 4 — Enrichment และ assets ที่ผ่านสิทธิ์

- เพิ่ม Thai MOOC/OER/OpenStax/OpenLearn/Pressbooks เป็น reading, micro-lesson หรือ case study ตาม license
- เพิ่มภาพจาก Commons/Openverse/GeoGebra เฉพาะไฟล์ที่ผ่าน per-file check และมี attribution bundle
- สร้างหน้า attribution และปุ่ม deep-link สำหรับแหล่ง restricted แทน download/rehost

### Phase 5 — QA, release และ review cycle

- ตรวจ alignment และห้ามใช้ source title เป็น indicator
- ตรวจ factual/age appropriateness; เนื้อหาสุขภาพ กฎหมาย ราคา เกษตร และดิจิทัลต้องมี `last_checked`
- ตรวจ license regression ทุกครั้งที่เปลี่ยน asset หรือดัดแปลงเนื้อหา
- ออกรุ่นข้อมูลพร้อม `version`, `change_log`, `reviewer`, `reviewed_at`; record ที่ยังไม่มีสิทธิ์หรือ mapping ให้คงสถานะ `needs_review` และไม่เผยแพร่สาธารณะ

## 8) Definition of done ต่อ record

- [ ] ระบุ subject, grade/grade_band, term และ course/unit key
- [ ] ระบุ framework, strand, standard/indicator และ `alignment_status`
- [ ] มี learning outcomes และ prerequisites
- [ ] มีกิจกรรมที่ทำได้จริง พร้อม materials/procedure/safety เมื่อเกี่ยวข้อง
- [ ] มี assessment evidence และ expected artifact/rubric
- [ ] มี source URL, source type, title/owner และ `last_checked`
- [ ] มี license status, raw license evidence, attribution และข้อจำกัดการแก้ไข/เผยแพร่
- [ ] ถ้าเป็นภาพ/เสียง/วิดีโอ มี rights record รายไฟล์
- [ ] ถ้า ม.4–ม.6 มี school sequence และระบุว่า proposed/verified
- [ ] ผ่าน reviewer เหมาะกับความเสี่ยงของเนื้อหา และเก็บ change log

## 9) ข้อสรุป

แผน seed ที่ปลอดภัยที่สุดคือการสร้าง **catalog ของกรอบ + หน่วย + หลักฐานการเรียนรู้ + provenance/rights** ไม่ใช่คลังสำเนาสื่อ การเริ่มจาก ม.1–ม.3 ที่มี teachable evidence แล้วขยายไป ม.4–ม.6 แบบ grade-band/proposed progression จะลดความเสี่ยงเรื่องการอ้างตัวชี้วัดผิดและลำดับสอนผิดโรงเรียน ส่วน Thai MOOC/OER และรูปภาพควรเป็นชั้น enrichment หลัง rights gate เท่านั้น
