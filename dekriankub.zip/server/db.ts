import { and, desc, eq, like, or } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, curricula, grades, lessonSources, lessons, subjects, units, users } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    throw new Error("Database is not available");
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function listCatalogLessons(filters: { search?: string; grade?: string; subject?: string; limit?: number }) {
  const db = await getDb();
  if (!db) return [];

  const conditions = [eq(lessons.status, "published")];
  if (filters.grade) conditions.push(eq(grades.code, filters.grade));
  if (filters.subject) conditions.push(eq(subjects.code, filters.subject));
  if (filters.search) {
    const search = `%${filters.search}%`;
    conditions.push(or(like(lessons.title, search), like(lessons.summary, search))!);
  }

  const rows = await db
    .select({
      id: lessons.id,
      title: lessons.title,
      slug: lessons.slug,
      summary: lessons.summary,
      durationMinutes: lessons.durationMinutes,
      difficulty: lessons.difficulty,
      coverAssetUrl: lessons.coverAssetUrl,
      subjectCode: subjects.code,
      subjectName: subjects.name,
      gradeCode: grades.code,
      gradeLabel: grades.label,
      curriculumName: curricula.name,
    })
    .from(lessons)
    .innerJoin(units, eq(lessons.unitId, units.id))
    .innerJoin(subjects, eq(units.subjectId, subjects.id))
    .innerJoin(grades, eq(units.gradeId, grades.id))
    .innerJoin(curricula, eq(units.curriculumId, curricula.id))
    .where(and(...conditions))
    .orderBy(desc(lessons.updatedAt))
    .limit(Math.min(Math.max(filters.limit ?? 24, 1), 100));

  return rows;
}

export async function getCatalogLessonById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const lesson = (await db
    .select({
      id: lessons.id,
      title: lessons.title,
      slug: lessons.slug,
      summary: lessons.summary,
      content: lessons.content,
      durationMinutes: lessons.durationMinutes,
      difficulty: lessons.difficulty,
      coverAssetUrl: lessons.coverAssetUrl,
      subjectCode: subjects.code,
      subjectName: subjects.name,
      gradeCode: grades.code,
      gradeLabel: grades.label,
      unitTitle: units.title,
      curriculumName: curricula.name,
    })
    .from(lessons)
    .innerJoin(units, eq(lessons.unitId, units.id))
    .innerJoin(subjects, eq(units.subjectId, subjects.id))
    .innerJoin(grades, eq(units.gradeId, grades.id))
    .innerJoin(curricula, eq(units.curriculumId, curricula.id))
    .where(and(eq(lessons.id, id), eq(lessons.status, "published")))
    .limit(1))[0];
  if (!lesson) return null;
  const sources = await db.select().from(lessonSources).where(eq(lessonSources.lessonId, id));
  return { ...lesson, sources };
}
