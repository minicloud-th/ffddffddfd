import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, index, uniqueIndex } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const curricula = mysqlTable("curricula", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  version: varchar("version", { length: 80 }).notNull(),
  countryCode: varchar("countryCode", { length: 8 }).default("TH").notNull(),
  languageCode: varchar("languageCode", { length: 12 }).default("th").notNull(),
  sourceUrl: varchar("sourceUrl", { length: 1024 }),
  status: mysqlEnum("status", ["draft", "active", "archived"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => ({
  countryVersionIdx: uniqueIndex("curricula_country_version_idx").on(table.countryCode, table.version),
}));

export const grades = mysqlTable("grades", {
  id: int("id").autoincrement().primaryKey(),
  code: varchar("code", { length: 12 }).notNull().unique(),
  label: varchar("label", { length: 80 }).notNull(),
  sortOrder: int("sortOrder").notNull(),
});

export const subjects = mysqlTable("subjects", {
  id: int("id").autoincrement().primaryKey(),
  code: varchar("code", { length: 40 }).notNull().unique(),
  groupKey: varchar("groupKey", { length: 40 }).notNull(),
  name: varchar("name", { length: 160 }).notNull(),
  iconKey: varchar("iconKey", { length: 40 }).default("book").notNull(),
  sortOrder: int("sortOrder").notNull(),
});

export const units = mysqlTable("units", {
  id: int("id").autoincrement().primaryKey(),
  curriculumId: int("curriculumId").notNull().references(() => curricula.id),
  subjectId: int("subjectId").notNull().references(() => subjects.id),
  gradeId: int("gradeId").notNull().references(() => grades.id),
  title: varchar("title", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 220 }).notNull(),
  summary: text("summary"),
  term: varchar("term", { length: 40 }),
  learningOutcomes: text("learningOutcomes"),
  assessmentEvidence: text("assessmentEvidence"),
  alignmentStatus: mysqlEnum("alignmentStatus", ["verified", "proposed", "needs_review"]).default("proposed").notNull(),
  schoolSequence: int("schoolSequence"),
  sortOrder: int("sortOrder").default(0).notNull(),
  status: mysqlEnum("status", ["draft", "published", "archived"]).default("published").notNull(),
}, table => ({
  curriculumGradeIdx: index("units_curriculum_grade_idx").on(table.curriculumId, table.gradeId),
  slugIdx: uniqueIndex("units_slug_idx").on(table.slug),
}));

export const lessons = mysqlTable("lessons", {
  id: int("id").autoincrement().primaryKey(),
  unitId: int("unitId").notNull().references(() => units.id),
  title: varchar("title", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 220 }).notNull(),
  languageCode: varchar("languageCode", { length: 12 }).default("th").notNull(),
  summary: text("summary"),
  content: text("content"),
  durationMinutes: int("durationMinutes").default(10).notNull(),
  difficulty: mysqlEnum("difficulty", ["easy", "medium", "hard"]).default("medium").notNull(),
  status: mysqlEnum("status", ["draft", "published", "archived"]).default("published").notNull(),
  coverAssetUrl: varchar("coverAssetUrl", { length: 1024 }),
  publishedAt: timestamp("publishedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => ({
  unitLanguageIdx: index("lessons_unit_language_idx").on(table.unitId, table.languageCode),
  slugIdx: uniqueIndex("lessons_slug_idx").on(table.slug),
}));

export const lessonSources = mysqlTable("lesson_sources", {
  id: int("id").autoincrement().primaryKey(),
  lessonId: int("lessonId").notNull().references(() => lessons.id),
  sourceUrl: varchar("sourceUrl", { length: 1024 }).notNull(),
  sourceTitle: varchar("sourceTitle", { length: 255 }).notNull(),
  sourceType: varchar("sourceType", { length: 60 }).default("official").notNull(),
  license: varchar("license", { length: 255 }),
  licenseUrl: varchar("licenseUrl", { length: 1024 }),
  rightsStatus: varchar("rightsStatus", { length: 60 }).default("unknown").notNull(),
  attribution: varchar("attribution", { length: 512 }),
  canModify: int("canModify").default(0).notNull(),
  canRedistribute: int("canRedistribute").default(0).notNull(),
  doNotRepublish: int("doNotRepublish").default(0).notNull(),
  rawLicenseText: text("rawLicenseText"),
  checkedAt: timestamp("checkedAt").defaultNow().notNull(),
}, table => ({
  lessonIdx: index("lesson_sources_lesson_idx").on(table.lessonId),
}));

export const lessonAssets = mysqlTable("lesson_assets", {
  id: int("id").autoincrement().primaryKey(),
  lessonId: int("lessonId").notNull().references(() => lessons.id),
  storagePath: varchar("storagePath", { length: 512 }),
  stableUrl: varchar("stableUrl", { length: 1024 }).notNull(),
  altText: varchar("altText", { length: 255 }).notNull(),
  role: varchar("role", { length: 40 }).default("illustration").notNull(),
  attribution: varchar("attribution", { length: 512 }),
  license: varchar("license", { length: 255 }),
  licenseUrl: varchar("licenseUrl", { length: 1024 }),
  lastCheckedAt: timestamp("lastCheckedAt").defaultNow().notNull(),
}, table => ({
  lessonIdx: index("lesson_assets_lesson_idx").on(table.lessonId),
}));

export const lessonTranslations = mysqlTable("lesson_translations", {
  id: int("id").autoincrement().primaryKey(),
  lessonId: int("lessonId").notNull().references(() => lessons.id),
  languageCode: varchar("languageCode", { length: 12 }).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  summary: text("summary"),
  content: text("content"),
}, table => ({
  lessonLanguageIdx: uniqueIndex("lesson_translations_language_idx").on(table.lessonId, table.languageCode),
}));

export const quizQuestions = mysqlTable("quiz_questions", {
  id: int("id").autoincrement().primaryKey(),
  lessonId: int("lessonId").notNull().references(() => lessons.id),
  question: text("question").notNull(),
  explanation: text("explanation"),
  difficulty: mysqlEnum("difficulty", ["easy", "medium", "hard"]).default("medium").notNull(),
  sortOrder: int("sortOrder").default(0).notNull(),
}, table => ({
  lessonIdx: index("quiz_questions_lesson_idx").on(table.lessonId),
}));

export const quizOptions = mysqlTable("quiz_options", {
  id: int("id").autoincrement().primaryKey(),
  questionId: int("questionId").notNull().references(() => quizQuestions.id),
  optionText: text("optionText").notNull(),
  isCorrect: int("isCorrect").default(0).notNull(),
  sortOrder: int("sortOrder").default(0).notNull(),
}, table => ({
  questionIdx: index("quiz_options_question_idx").on(table.questionId),
}));

export const studyProgress = mysqlTable("study_progress", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  lessonId: int("lessonId").notNull().references(() => lessons.id),
  percent: int("percent").default(0).notNull(),
  status: mysqlEnum("status", ["not_started", "in_progress", "completed"]).default("not_started").notNull(),
  lastViewedAt: timestamp("lastViewedAt"),
  completedAt: timestamp("completedAt"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => ({
  userLessonIdx: uniqueIndex("study_progress_user_lesson_idx").on(table.userId, table.lessonId),
}));

export type Curriculum = typeof curricula.$inferSelect;
export type InsertCurriculum = typeof curricula.$inferInsert;
export type Grade = typeof grades.$inferSelect;
export type SubjectRecord = typeof subjects.$inferSelect;
export type Unit = typeof units.$inferSelect;
export type LessonRecord = typeof lessons.$inferSelect;
export type LessonSource = typeof lessonSources.$inferSelect;
export type LessonAsset = typeof lessonAssets.$inferSelect;
export type LessonTranslation = typeof lessonTranslations.$inferSelect;
