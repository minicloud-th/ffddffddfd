CREATE TABLE `curricula` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`version` varchar(80) NOT NULL,
	`countryCode` varchar(8) NOT NULL DEFAULT 'TH',
	`languageCode` varchar(12) NOT NULL DEFAULT 'th',
	`sourceUrl` varchar(1024),
	`status` enum('draft','active','archived') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `curricula_id` PRIMARY KEY(`id`),
	CONSTRAINT `curricula_country_version_idx` UNIQUE(`countryCode`,`version`)
);
--> statement-breakpoint
CREATE TABLE `grades` (
	`id` int AUTO_INCREMENT NOT NULL,
	`code` varchar(12) NOT NULL,
	`label` varchar(80) NOT NULL,
	`sortOrder` int NOT NULL,
	CONSTRAINT `grades_id` PRIMARY KEY(`id`),
	CONSTRAINT `grades_code_unique` UNIQUE(`code`)
);
--> statement-breakpoint
CREATE TABLE `lesson_assets` (
	`id` int AUTO_INCREMENT NOT NULL,
	`lessonId` int NOT NULL,
	`storagePath` varchar(512),
	`stableUrl` varchar(1024) NOT NULL,
	`altText` varchar(255) NOT NULL,
	`role` varchar(40) NOT NULL DEFAULT 'illustration',
	`attribution` varchar(512),
	`license` varchar(255),
	CONSTRAINT `lesson_assets_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `lesson_sources` (
	`id` int AUTO_INCREMENT NOT NULL,
	`lessonId` int NOT NULL,
	`sourceUrl` varchar(1024) NOT NULL,
	`sourceTitle` varchar(255) NOT NULL,
	`sourceType` varchar(60) NOT NULL DEFAULT 'official',
	`license` varchar(255),
	`checkedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `lesson_sources_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `lesson_translations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`lessonId` int NOT NULL,
	`languageCode` varchar(12) NOT NULL,
	`title` varchar(255) NOT NULL,
	`summary` text,
	`content` text,
	CONSTRAINT `lesson_translations_id` PRIMARY KEY(`id`),
	CONSTRAINT `lesson_translations_language_idx` UNIQUE(`lessonId`,`languageCode`)
);
--> statement-breakpoint
CREATE TABLE `lessons` (
	`id` int AUTO_INCREMENT NOT NULL,
	`unitId` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`slug` varchar(220) NOT NULL,
	`languageCode` varchar(12) NOT NULL DEFAULT 'th',
	`summary` text,
	`content` text,
	`durationMinutes` int NOT NULL DEFAULT 10,
	`difficulty` enum('easy','medium','hard') NOT NULL DEFAULT 'medium',
	`status` enum('draft','published','archived') NOT NULL DEFAULT 'published',
	`coverAssetUrl` varchar(1024),
	`publishedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `lessons_id` PRIMARY KEY(`id`),
	CONSTRAINT `lessons_slug_idx` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `quiz_options` (
	`id` int AUTO_INCREMENT NOT NULL,
	`questionId` int NOT NULL,
	`optionText` text NOT NULL,
	`isCorrect` int NOT NULL DEFAULT 0,
	`sortOrder` int NOT NULL DEFAULT 0,
	CONSTRAINT `quiz_options_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `quiz_questions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`lessonId` int NOT NULL,
	`question` text NOT NULL,
	`explanation` text,
	`difficulty` enum('easy','medium','hard') NOT NULL DEFAULT 'medium',
	`sortOrder` int NOT NULL DEFAULT 0,
	CONSTRAINT `quiz_questions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `study_progress` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`lessonId` int NOT NULL,
	`percent` int NOT NULL DEFAULT 0,
	`status` enum('not_started','in_progress','completed') NOT NULL DEFAULT 'not_started',
	`lastViewedAt` timestamp,
	`completedAt` timestamp,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `study_progress_id` PRIMARY KEY(`id`),
	CONSTRAINT `study_progress_user_lesson_idx` UNIQUE(`userId`,`lessonId`)
);
--> statement-breakpoint
CREATE TABLE `subjects` (
	`id` int AUTO_INCREMENT NOT NULL,
	`code` varchar(40) NOT NULL,
	`groupKey` varchar(40) NOT NULL,
	`name` varchar(160) NOT NULL,
	`iconKey` varchar(40) NOT NULL DEFAULT 'book',
	`sortOrder` int NOT NULL,
	CONSTRAINT `subjects_id` PRIMARY KEY(`id`),
	CONSTRAINT `subjects_code_unique` UNIQUE(`code`)
);
--> statement-breakpoint
CREATE TABLE `units` (
	`id` int AUTO_INCREMENT NOT NULL,
	`curriculumId` int NOT NULL,
	`subjectId` int NOT NULL,
	`gradeId` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`slug` varchar(220) NOT NULL,
	`summary` text,
	`sortOrder` int NOT NULL DEFAULT 0,
	`status` enum('draft','published','archived') NOT NULL DEFAULT 'published',
	CONSTRAINT `units_id` PRIMARY KEY(`id`),
	CONSTRAINT `units_slug_idx` UNIQUE(`slug`)
);
--> statement-breakpoint
ALTER TABLE `lesson_assets` ADD CONSTRAINT `lesson_assets_lessonId_lessons_id_fk` FOREIGN KEY (`lessonId`) REFERENCES `lessons`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `lesson_sources` ADD CONSTRAINT `lesson_sources_lessonId_lessons_id_fk` FOREIGN KEY (`lessonId`) REFERENCES `lessons`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `lesson_translations` ADD CONSTRAINT `lesson_translations_lessonId_lessons_id_fk` FOREIGN KEY (`lessonId`) REFERENCES `lessons`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `lessons` ADD CONSTRAINT `lessons_unitId_units_id_fk` FOREIGN KEY (`unitId`) REFERENCES `units`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `quiz_options` ADD CONSTRAINT `quiz_options_questionId_quiz_questions_id_fk` FOREIGN KEY (`questionId`) REFERENCES `quiz_questions`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `quiz_questions` ADD CONSTRAINT `quiz_questions_lessonId_lessons_id_fk` FOREIGN KEY (`lessonId`) REFERENCES `lessons`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `study_progress` ADD CONSTRAINT `study_progress_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `study_progress` ADD CONSTRAINT `study_progress_lessonId_lessons_id_fk` FOREIGN KEY (`lessonId`) REFERENCES `lessons`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `units` ADD CONSTRAINT `units_curriculumId_curricula_id_fk` FOREIGN KEY (`curriculumId`) REFERENCES `curricula`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `units` ADD CONSTRAINT `units_subjectId_subjects_id_fk` FOREIGN KEY (`subjectId`) REFERENCES `subjects`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `units` ADD CONSTRAINT `units_gradeId_grades_id_fk` FOREIGN KEY (`gradeId`) REFERENCES `grades`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `lesson_assets_lesson_idx` ON `lesson_assets` (`lessonId`);--> statement-breakpoint
CREATE INDEX `lesson_sources_lesson_idx` ON `lesson_sources` (`lessonId`);--> statement-breakpoint
CREATE INDEX `lessons_unit_language_idx` ON `lessons` (`unitId`,`languageCode`);--> statement-breakpoint
CREATE INDEX `quiz_options_question_idx` ON `quiz_options` (`questionId`);--> statement-breakpoint
CREATE INDEX `quiz_questions_lesson_idx` ON `quiz_questions` (`lessonId`);--> statement-breakpoint
CREATE INDEX `units_curriculum_grade_idx` ON `units` (`curriculumId`,`gradeId`);