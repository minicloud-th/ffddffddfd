ALTER TABLE `lesson_assets` ADD `licenseUrl` varchar(1024);--> statement-breakpoint
ALTER TABLE `lesson_assets` ADD `lastCheckedAt` timestamp DEFAULT (now()) NOT NULL;--> statement-breakpoint
ALTER TABLE `lesson_sources` ADD `licenseUrl` varchar(1024);--> statement-breakpoint
ALTER TABLE `lesson_sources` ADD `rightsStatus` varchar(60) DEFAULT 'unknown' NOT NULL;--> statement-breakpoint
ALTER TABLE `lesson_sources` ADD `attribution` varchar(512);--> statement-breakpoint
ALTER TABLE `lesson_sources` ADD `canModify` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `lesson_sources` ADD `canRedistribute` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `lesson_sources` ADD `doNotRepublish` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `lesson_sources` ADD `rawLicenseText` text;--> statement-breakpoint
ALTER TABLE `units` ADD `term` varchar(40);--> statement-breakpoint
ALTER TABLE `units` ADD `learningOutcomes` text;--> statement-breakpoint
ALTER TABLE `units` ADD `assessmentEvidence` text;--> statement-breakpoint
ALTER TABLE `units` ADD `alignmentStatus` enum('verified','proposed','needs_review') DEFAULT 'proposed' NOT NULL;--> statement-breakpoint
ALTER TABLE `units` ADD `schoolSequence` int;