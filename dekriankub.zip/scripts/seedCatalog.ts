import "dotenv/config";
import mysql from "mysql2/promise";
import { and, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { curricula, grades, lessonSources, lessons, subjects, units } from "../drizzle/schema";

const curriculumSeed = {
  name: "หลักสูตรแกนกลางการศึกษาขั้นพื้นฐาน",
  version: "2551-ปรับปรุง-2560",
  countryCode: "TH",
  languageCode: "th",
  sourceUrl: "https://academic.obec.go.th/images/document/1559878925_d_1.pdf",
  status: "active" as const,
};

const gradeSeed = ["ม.1", "ม.2", "ม.3", "ม.4", "ม.5", "ม.6"].map((label, index) => ({
  code: `M${index + 1}`,
  label,
  sortOrder: index + 1,
}));

const subjectSeed = [
  { code: "TH", groupKey: "thai", name: "ภาษาไทย", iconKey: "book", sourceUrl: "https://academic.obec.go.th/images/document/1559639270_d_1.pdf", sourceTitle: "กรอบหลักสูตรภาษาไทย สพฐ.", openUrl: "https://learn.thaimooc.ac.th/courses/course-v1:UP+00754+0/", openTitle: "Thai MOOC 00754", license: "CC BY-NC-SA 4.0", rightsStatus: "permission_required", units: ["อ่านจับใจความและสรุปความ", "อ่านสื่อร่วมสมัยและแยกข้อเท็จจริง", "อ่านเชิงวิจารณ์และสารโน้มน้าว", "อ่านตีความและงานวิชาการ", "วิเคราะห์วิจารณ์และสังเคราะห์", "เขียนเชิงวิชาการและสร้างสรรค์"] },
  { code: "MA", groupKey: "math", name: "คณิตศาสตร์", iconKey: "sigma", sourceUrl: "https://www.ipst.ac.th/curriculum", sourceTitle: "หลักสูตรคณิตศาสตร์ สสวท.", openUrl: "https://lms.thaimooc.org/courses/course-v1:SSRU+SSRU007+2019/about", openTitle: "Thai MOOC คณิตพิชิต O-NET", license: "CC BY-SA-NC", rightsStatus: "permission_required", units: ["จำนวนเต็ม เลขยกกำลัง และสมการ", "จำนวนจริง พหุนาม และสถิติ", "สมการกำลังสอง ความคล้าย และความน่าจะเป็น", "เซต ตรรกศาสตร์ และหลักการนับ", "ฟังก์ชัน ลำดับ และตรีโกณมิติ", "สถิติ ความน่าจะเป็น และแคลคูลัสเบื้องต้น"] },
  { code: "SC", groupKey: "science", name: "วิทยาศาสตร์และเทคโนโลยี", iconKey: "flask", sourceUrl: "https://www.ipst.ac.th/curriculum", sourceTitle: "หลักสูตรวิทยาศาสตร์และเทคโนโลยี สสวท.", openUrl: "https://proj14.ipst.ac.th/", openTitle: "Project 14 สสวท.", license: "official reference; ตรวจสิทธิ์รายไฟล์", rightsStatus: "official-reference", units: ["สาร สิ่งมีชีวิต และลมฟ้าอากาศ", "สารละลาย ร่างกาย แรง และพลังงาน", "พันธุศาสตร์ คลื่น ไฟฟ้า และระบบนิเวศ", "ชีวภาพและวิทยาการคำนวณ", "กายภาพ วิทยาการข้อมูล และภาพข้อมูล", "โลก ดาราศาสตร์ AI และพลเมืองดิจิทัล"] },
  { code: "SO", groupKey: "social", name: "สังคมศึกษา ศาสนา และวัฒนธรรม", iconKey: "globe", sourceUrl: "https://academic.obec.go.th/web/news/view/75", sourceTitle: "กรอบหลักสูตรสังคมศึกษา สพฐ.", openUrl: "https://openstax.org/books/principles-economics-3e/pages/1-introduction", openTitle: "OpenStax Principles of Economics", license: "CC BY-NC-SA 4.0", rightsStatus: "permission_required", units: ["ศาสนา จริยธรรม และภูมิศาสตร์เอเชีย", "พลเมือง กฎหมาย เศรษฐศาสตร์ และเอเชีย", "ประชาธิปไตย โลกาภิวัตน์ และประวัติศาสตร์โลก", "นิติธรรม เศรษฐศาสตร์จุลภาค และหลักฐาน", "เศรษฐศาสตร์มหภาค ทรัพยากร และสันติภาพ", "นโยบายสาธารณะ การเงิน และภูมิศาสตร์โลก"] },
  { code: "HP", groupKey: "health", name: "สุขศึกษาและพลศึกษา", iconKey: "heart", sourceUrl: "https://academic.obec.go.th/images/document/1559639643_d_1.pdf", sourceTitle: "กรอบสุขศึกษาและพลศึกษา สพฐ.", openUrl: "https://openstax.org/details/books/anatomy-and-physiology-2e", openTitle: "OpenStax Anatomy and Physiology 2e", license: "CC BY-NC-SA 4.0", rightsStatus: "permission_required", units: ["วัยรุ่น โภชนาการ และความปลอดภัย", "สุขภาพวัยรุ่น เพศศึกษา และสารเสพติด", "อนามัยเจริญพันธุ์ สุขภาพ และกีฬา", "ระบบอวัยวะ สุขภาพจิต และปฐมพยาบาล", "สุขภาพทางเพศ โภชนาการ และผู้นำกีฬา", "สุขภาพตลอดชีวิต วิทยาศาสตร์การกีฬา และชุมชน"] },
  { code: "AR", groupKey: "arts", name: "ศิลปะ", iconKey: "palette", sourceUrl: "https://academic.obec.go.th/web/document/view/109", sourceTitle: "กรอบหลักสูตรศิลปะ สพฐ.", openUrl: "https://learn.thaimooc.ac.th/courses/course-v1:SU+00689+0/", openTitle: "Thai MOOC มนุษย์กับศิลปะ", license: "CC BY-NC-SA", rightsStatus: "permission_required", units: ["ทัศนธาตุ ดนตรี และนาฏศัพท์", "ลายเส้น ดนตรี และการออกแบบการแสดง", "สื่อผสม ดนตรี และโครงงานการแสดง", "ศัพท์ศิลปะ ทฤษฎีสี และประวัติศิลป์", "สื่อผสม การประพันธ์ และ stagecraft", "ดิจิทัลดีไซน์ portfolio และศิลปะร่วมสมัย"] },
  { code: "CA", groupKey: "career", name: "การงานอาชีพ", iconKey: "briefcase", sourceUrl: "https://academic.obec.go.th/web/news/view/75", sourceTitle: "กรอบหลักสูตรการงานอาชีพ สพฐ.", openUrl: "https://learn.thaimooc.ac.th/courses/course-v1:SRU+00613+0/about", openTitle: "Thai MOOC ทักษะงานและอาชีพ", license: "CC BY-NC-SA", rightsStatus: "permission_required", units: ["บ้านน่าอยู่ งานประดิษฐ์ และต้นอ่อน", "ซ่อมแซม ขยายพันธุ์ และใช้ซ้ำ", "อาหาร แปรรูป และธุรกิจชุมชน", "โลกงาน ทักษะชีวิต และความปลอดภัย", "เกษตรยั่งยืน ต้นทุน และการตลาด", "แฟ้มสะสมงาน อาชีพ และโครงงานปลายทาง"] },
  { code: "LA", groupKey: "languages", name: "ภาษาต่างประเทศ", iconKey: "languages", sourceUrl: "http://www.academic.obec.go.th/web/document/view/104", sourceTitle: "กรอบหลักสูตรภาษาต่างประเทศ สพฐ.", openUrl: "https://lms.thaimooc.org/courses/course-v1:UP+UP001+2017/about", openTitle: "Thai MOOC ภาษาอังกฤษ", license: "CC BY-NC-SA", rightsStatus: "permission_required", units: ["All of Me: แนะนำตนและครอบครัว", "Home and Community: ชีวิตประจำวัน", "Leisure, Health and Entertainment", "Science, Technology and Culture", "Environment, Travel and Presentation", "Occupation, Research and B1 Portfolio"] },
];

const subjectImages: Record<string, string> = {
  TH: "/manus-storage/async-images/96CYSm4IeHmlsSqHILDrwM/image-1.webp",
  MA: "/manus-storage/async-images/96CYSm4IeHmlsSqHILDrwM/image-2.webp",
  SC: "/manus-storage/async-images/96CYSm4IeHmlsSqHILDrwM/image-3.webp",
  SO: "/manus-storage/async-images/96CYSm4IeHmlsSqHILDrwM/image-4.webp",
  HP: "/manus-storage/async-images/96CYSm4IeHmlsSqHILDrwM/image-5.webp",
  AR: "/manus-storage/async-images/ksop3BxzkTsUVu6ysW4x4k/image-1.webp",
  CA: "/manus-storage/async-images/ksop3BxzkTsUVu6ysW4x4k/image-2.webp",
  LA: "/manus-storage/async-images/ksop3BxzkTsUVu6ysW4x4k/image-3.webp",
};

function slug(value: string) {
  return value.toLowerCase().replace(/[^a-z0-9ก-๙]+/g, "-").replace(/^-|-$/g, "");
}

async function main() {
  if (!process.env.DATABASE_URL) throw new Error("DATABASE_URL is required");
  const connection = await mysql.createConnection(process.env.DATABASE_URL);
  const db = drizzle(connection);

  let curriculum = (await db.select().from(curricula).where(and(eq(curricula.countryCode, curriculumSeed.countryCode), eq(curricula.version, curriculumSeed.version))).limit(1))[0];
  if (!curriculum) {
    await db.insert(curricula).values(curriculumSeed);
    curriculum = (await db.select().from(curricula).where(and(eq(curricula.countryCode, curriculumSeed.countryCode), eq(curricula.version, curriculumSeed.version))).limit(1))[0];
  }
  if (!curriculum) throw new Error("Could not create curriculum");

  const gradeIds = new Map<string, number>();
  for (const grade of gradeSeed) {
    let row = (await db.select().from(grades).where(eq(grades.code, grade.code)).limit(1))[0];
    if (!row) {
      await db.insert(grades).values(grade);
      row = (await db.select().from(grades).where(eq(grades.code, grade.code)).limit(1))[0];
    }
    if (row) gradeIds.set(grade.code, row.id);
  }

  for (const [subjectIndex, subjectSeedItem] of subjectSeed.entries()) {
    let subject = (await db.select().from(subjects).where(eq(subjects.code, subjectSeedItem.code)).limit(1))[0];
    if (!subject) {
      await db.insert(subjects).values({ code: subjectSeedItem.code, groupKey: subjectSeedItem.groupKey, name: subjectSeedItem.name, iconKey: subjectSeedItem.iconKey, sortOrder: subjectIndex + 1 });
      subject = (await db.select().from(subjects).where(eq(subjects.code, subjectSeedItem.code)).limit(1))[0];
    }
    if (!subject) continue;

    for (let gradeIndex = 0; gradeIndex < gradeSeed.length; gradeIndex += 1) {
      const grade = gradeSeed[gradeIndex];
      const gradeId = gradeIds.get(grade.code);
      if (!gradeId) continue;
      const title = subjectSeedItem.units[gradeIndex];
      const unitSlug = `${subjectSeedItem.code.toLowerCase()}-${grade.code.toLowerCase()}-${slug(title)}`;
      let unit = (await db.select().from(units).where(eq(units.slug, unitSlug)).limit(1))[0];
      if (!unit) {
        await db.insert(units).values({
          curriculumId: curriculum.id,
          subjectId: subject.id,
          gradeId,
          title,
          slug: unitSlug,
          summary: `หน่วยเรียน ${title} สำหรับ ${grade.label} จัดโครงจากกรอบหลักสูตรไทยและแหล่งอ้างอิงที่ตรวจสอบแล้ว`,
          term: "ตลอดปี",
          learningOutcomes: `อธิบายแนวคิดสำคัญของ${title} และนำไปใช้กับตัวอย่างใกล้ตัวได้`,
          assessmentEvidence: "สรุปความเข้าใจ แบบฝึกหัด หรือชิ้นงานสั้น",
          alignmentStatus: gradeIndex < 3 ? "verified" : "proposed",
          schoolSequence: gradeIndex + 1,
          sortOrder: gradeIndex + 1,
          status: "published",
        });
        unit = (await db.select().from(units).where(eq(units.slug, unitSlug)).limit(1))[0];
      }
      if (!unit) continue;

      const lessonSlug = `${unitSlug}-micro-lesson`;
      let lesson = (await db.select().from(lessons).where(eq(lessons.slug, lessonSlug)).limit(1))[0];
      if (!lesson) {
        await db.insert(lessons).values({
          unitId: unit.id,
          title: `เรียนเร็ว: ${title}`,
          slug: lessonSlug,
          languageCode: "th",
          summary: `บทเรียน micro-lesson สำหรับ ${grade.label} ใช้เวลา 10 นาที พร้อมเป้าหมาย กิจกรรมสั้น และหลักฐานการเรียนรู้`,
          content: `เริ่มจากคำถามนำเข้าสั้น ๆ → อ่านแนวคิดหลัก → ลองทำตัวอย่าง → สรุปด้วยภาษาของตัวเอง → ตรวจความเข้าใจด้วยคำถามท้ายบท\n\nสถานะเนื้อหา: ${gradeIndex < 3 ? "มีหลักฐานกรอบ/หน่วยระดับชั้นแล้ว" : "หน่วยเสนอเพื่อจัด progression ม.ปลาย ต้องตรวจหลักสูตรสถานศึกษา"}`,
          durationMinutes: 10,
          difficulty: gradeIndex < 2 ? "easy" : gradeIndex < 4 ? "medium" : "hard",
          status: "published",
          publishedAt: new Date(),
        });
        lesson = (await db.select().from(lessons).where(eq(lessons.slug, lessonSlug)).limit(1))[0];
      }
      if (!lesson) continue;

      if (!lesson.coverAssetUrl && subjectImages[subjectSeedItem.code]) {
        await db.update(lessons).set({ coverAssetUrl: subjectImages[subjectSeedItem.code] }).where(eq(lessons.id, lesson.id));
      }

      const sourceExists = (await db.select().from(lessonSources).where(and(eq(lessonSources.lessonId, lesson.id), eq(lessonSources.sourceUrl, subjectSeedItem.sourceUrl))).limit(1))[0];
      if (!sourceExists) {
        await db.insert(lessonSources).values({
          lessonId: lesson.id,
          sourceUrl: subjectSeedItem.sourceUrl,
          sourceTitle: subjectSeedItem.sourceTitle,
          sourceType: "official",
          license: "official-reference",
          licenseUrl: "",
          rightsStatus: "official-reference",
          attribution: subjectSeedItem.sourceTitle,
          canModify: 0,
          canRedistribute: 0,
          doNotRepublish: 1,
          rawLicenseText: "เข้าถึงจากแหล่งทางการ; ตรวจสิทธิ์รายไฟล์ก่อนคัดลอกหรือเผยแพร่ซ้ำ",
        });
      }
      const openSourceExists = (await db.select().from(lessonSources).where(and(eq(lessonSources.lessonId, lesson.id), eq(lessonSources.sourceUrl, subjectSeedItem.openUrl))).limit(1))[0];
      if (!openSourceExists) {
        await db.insert(lessonSources).values({
          lessonId: lesson.id,
          sourceUrl: subjectSeedItem.openUrl,
          sourceTitle: subjectSeedItem.openTitle,
          sourceType: "open-content",
          license: subjectSeedItem.license,
          licenseUrl: "https://creativecommons.org/licenses/by-nc-sa/4.0/",
          rightsStatus: subjectSeedItem.rightsStatus,
          attribution: subjectSeedItem.openTitle,
          canModify: 0,
          canRedistribute: 0,
          doNotRepublish: 0,
          rawLicenseText: "ใช้ได้ต่อเมื่อทำตาม license ของต้นทางและตรวจสื่อบุคคลที่สามรายไฟล์",
        });
      }
    }
  }
  await connection.end();
  console.log("Seeded curriculum catalog: 8 subject groups x 6 grades with reference metadata.");
}

main().catch(error => { console.error(error); process.exit(1); });
