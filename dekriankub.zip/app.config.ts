export default {
  logoUrl: "https://dummyimage.com/256x256/20252d/ffffff.png&text=dk",
};
