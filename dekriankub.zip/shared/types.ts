/**
 * Shared domain types for dekriankub.
 * The prototype keeps records in the client, while these shapes are ready for tRPC/Drizzle later.
 */
export type * from "../drizzle/schema";
export * from "./_core/errors";

export type Subject = string;
export type Difficulty = "ง่าย" | "ปานกลาง" | "ยาก";

export type VocabularyItem = {
  term: string;
  meaning: string;
  example: string;
};

export type KeyPoint = {
  label: string;
  title: string;
  description: string;
  tone: "blue" | "dark" | "muted" | "green";
};

export type QuizQuestion = {
  id: string;
  question: string;
  options: string[];
  correctAnswer: string;
  explanation: string;
  topic: string;
};

export type Quiz = {
  id: string;
  title: string;
  totalQuestions: number;
  difficulty: Difficulty;
  questions: QuizQuestion[];
};

export type Lesson = {
  id: string;
  title: string;
  subject: Subject;
  grade: string;
  progress: number;
  quizCount: number;
  readingTime: string;
  vocabularyCount: number;
  difficulty: Difficulty;
  createdAt: string;
  updatedAt: string;
  starred: boolean;
  summary: string;
  detailSummary: string[];
  keyPoints: KeyPoint[];
  vocabulary: VocabularyItem[];
  quiz: Quiz;
  tags: string[];
};

export type StudyProgress = {
  streak: number;
  minutesThisWeek: number;
  lessonsCompleted: number;
  quizzesCompleted: number;
  weekly: { day: string; minutes: number; active: boolean }[];
};

export type ProcessingStep = {
  title: string;
  detail: string;
};

export type UploadedFile = {
  id: string;
  name: string;
  type: string;
  size: string;
  bytes: number;
  status: "ready" | "uploading" | "error";
};
