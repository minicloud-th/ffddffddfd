# dekriankub — Todo

## App shell และ routing พร้อมใช้งาน

สร้างโครงหน้าเว็บโดยใช้ sidebar สีดำอมเทาบน desktop, top bar, mobile bottom navigation หรือ drawer และ route `/`, `/upload`, `/lesson/:id`, `/quiz/:id`, `/library`, `/progress`, `/settings`, `/404`; เพิ่ม `public/manus-routes.json` ให้ประกาศ route ทั้งหมดรวม dynamic route และใช้ภาษาไทยทั้งหมด

## Design system ธีมดำออกเทา ขาว น้ำเงิน

ปรับ global tokens เป็นพื้นหลัง `#F7F8FA`, surface `#FFFFFF`, Sidebar `#20252D`, ข้อความหลัก `#1D232C`, ข้อความรอง `#5E6875`, สีหลัก `#2563EB`, hover `#1D4ED8`, highlight `#E8F0FF`, border `#DDE2E8`; ใช้เส้นขอบบาง มุมโค้งปานกลาง เงาน้อย spacing โปร่ง contrast อ่านง่าย focus state semantic labels keyboard navigation และ `prefers-reduced-motion`; wordmark `dekriankub` ต้องเป็นตัวพิมพ์เล็กพร้อมจุด/ขีดน้ำเงิน และไม่ใช้กราฟิกหุ่นยนต์/สมอง/วงจร

## Dashboard ใช้งานได้จริง

หน้า `/` ต้องแสดงข้อความ “สวัสดี วันนี้อยากเรียนเรื่องอะไรดี?” พร้อม CTA อัปโหลดไฟล์ เปิดคลังความรู้ และสร้างแบบทดสอบ; มี upload dropzone ขนาดใหญ่ที่รองรับการกดเลือกไฟล์และ drag-and-drop ใน prototype พร้อม feedback; มีบทเรียนล่าสุด progress การเรียนวันนี้ quiz แนะนำ ข้อมูลตัวอย่างภาษาไทย และ empty/success state โดยไม่ใช้ Lorem ipsum

## Upload และ processing flow

หน้า `/upload` ต้องมีฟอร์มชื่อชุดบทเรียน วิชา ระดับชั้น เป้าหมาย ความละเอียดสรุป รูปแบบภาษา และแท็ก; รองรับหลายไฟล์และแสดงชื่อ ชนิด ขนาด สถานะ และปุ่มลบก่อนวิเคราะห์; เมื่อเริ่มวิเคราะห์ต้องแสดง progress bar และ 5 ขั้นคือ กำลังอ่านไฟล์, กำลังแยกหัวข้อสำคัญ, กำลังเรียบเรียงสรุป, กำลังเตรียมแบบทดสอบ, พร้อมเรียนแล้ว; เมื่อเสร็จต้องไป lesson พร้อม success feedback และมีสถานะไฟล์ไม่รองรับ ไฟล์ใหญ่เกินไป และ error ที่บอกวิธีแก้เป็นภาษาไทย

## Lesson summary และ Ask AI

หน้า `/lesson/:id` ต้องมี header ชื่อบทเรียน วิชา ระดับชั้น วันที่ ปุ่มดาว แชร์ และเมนูเพิ่มเติม; มี tabs ภาพรวม สรุป ประเด็นสำคัญ คำศัพท์ แบบทดสอบ และถาม AI; แสดง overview cards, summary highlight/detail, key points, vocabulary search และปุ่มคัดลอก ดาวน์โหลด ทำให้ง่ายขึ้น และขยายหัวข้อ; Ask AI แบบ mock ต้องมี suggested prompts, input, loading, คำตอบภาษาไทย และ source references โดยตอบจากเอกสารจำลอง

## Quiz flow ครบวงจร

หน้า `/quiz/:id` ต้องมี setup สำหรับจำนวนข้อ ระดับความยาก รูปแบบ จับเวลา และหัวข้อ; หน้าทำข้อสอบต้องมี progress, `ข้อ x / n`, ตัวเลือกอ่านง่าย, ย้อนกลับ/ถัดไป, mark for review, answer status และ confirm ก่อนส่ง; หน้าผลลัพธ์ต้องมีคะแนน เปอร์เซ็นต์ เวลา จุดแข็ง หัวข้อควรทบทวน ข้อผิด เฉลย คำอธิบาย และปุ่มทำใหม่ ทบทวนข้อผิด และสร้างชุดใหม่

## Library, Progress และ Settings

หน้า Library ต้องค้นหา กรองตามวิชา/ระดับ/ดาว และแสดง no-result/empty state; หน้า Progress ต้องแสดงภาพรวมรายสัปดาห์ บทเรียนที่กำลังเรียน ความสำเร็จ และคำพูดให้กำลังใจ โดยไม่ใช้กราฟเกินจำเป็น; หน้า Settings ต้องมี preference แบบ mock เช่น รูปแบบภาษา การแจ้งเตือน และลด motion พร้อม feedback เมื่อบันทึก

## Mock data และ service boundaries

สร้างข้อมูลจำลองภาษาไทยอย่างน้อย 3 บทเรียน ได้แก่ ชีววิทยาเรื่องระบบย่อยอาหาร คณิตศาสตร์เรื่องฟังก์ชัน และประวัติศาสตร์เรื่องการปฏิวัติอุตสาหกรรม พร้อม summary, key points, vocabulary, quiz และ progress; สร้าง service สำหรับ async loading, upload simulation, processing steps, quiz scoring และ Ask AI response; แยก domain types และเตรียม boundary สำหรับต่อ upload/storage metadata, lesson persistence, chunk/summary/keypoint/retrieval/cache และ LLM จริงภายหลัง โดย prototype ไม่ส่งเอกสารจริงหรือใช้ token โดยไม่จำเป็น

## Backend readiness และ runtime

คง starter Express/tRPC/Drizzle และ health route `/api/health`; หากเพิ่ม migration ให้เป็น additive เท่านั้นและไม่ทำ destructive SQL; เพิ่ม `app.config.ts` พร้อม `logoUrl` แบบ HTTPS ที่เหมาะสมหรือใช้ wordmark โดยไม่ต้องมี asset ภายนอก; คง PORT/runtime และใช้ relative browser routes ไม่ส่ง internal host ออกไป

## Validation และ handoff

ต้องผ่าน `pnpm check`, `pnpm test`, `pnpm build`; `manus-routes.json` ต้องตอบ HTTP 200 และตรงกับ source; dev server ต้องพร้อมที่ port 3000; responsive desktop/tablet/mobile ต้องไม่มี horizontal overflow; ปุ่มหลักทุกปุ่มต้องมี interaction หรือ feedback; ต้องมี Loading, Empty, Uploading, Processing, Success, Error, no-result, file-type, file-size, slow-AI, no-document-data, incomplete-quiz, delete และ saved states; แก้ type/build/runtime errors ก่อน checkpoint และส่ง checkpoint ไป canonical `main` ตาม managed WebDev workflow
